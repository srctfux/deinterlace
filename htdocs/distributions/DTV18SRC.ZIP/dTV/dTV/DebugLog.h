void LOG(LPCSTR format, ...);
