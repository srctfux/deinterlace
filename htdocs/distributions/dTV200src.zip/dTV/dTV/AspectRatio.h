/////////////////////////////////////////////////////////////////////////////
// AspectRatio.h
/////////////////////////////////////////////////////////////////////////////
//
//	This file is subject to the terms of the GNU General Public License as
//	published by the Free Software Foundation.  A copy of this license is
//	included with this software distribution in the file COPYING.  If you
//	do not have a copy, you may obtain a copy by writing to the Free
//	Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
//
//	This software is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details
/////////////////////////////////////////////////////////////////////////////
//
// Aspect ratio contrl was started by Michael Samblanet <mike@cardobe.com>
// Moved into separate module by Mark D Rejhon.  
//
// The purpose of this module is all the calculations and handling necessary
// to map the source image onto the destination display, even if they are
// different aspect ratios.
//
/////////////////////////////////////////////////////////////////////////////
// Change Log
//
// Date          Developer             Changes
//
// 12 Sep 2000   Mark Rejhon           Centralized aspect ratio code
//                                     into separate module
//
/////////////////////////////////////////////////////////////////////////////

int     ProcessAspectRatioSelection(HWND hWnd, WORD wMenuID);
void    SetMenuAspectRatio(HWND hWnd);
void    WorkoutOverlaySize();
void    PaintOverlay(HWND hWnd);
int		FindAspectRatio(short** EvenField, short** OddField);
void	AdjustAspectRatio(short** EvenField, short** OddField);

extern long LuminanceThreshold;
extern long IgnoreNonBlackPixels;
extern long ZoomInFrameCount;
extern long AutoDetectAspect;
extern long AspectConsistencyTime;
extern long AspectHistoryTime;
