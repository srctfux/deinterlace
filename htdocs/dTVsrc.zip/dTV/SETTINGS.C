/////////////////////////////////////////////////////////////////////////////
// Settings.c
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2000 John Adcock.  All rights reserved.
/////////////////////////////////////////////////////////////////////////////
//
//	This file is subject to the terms of the GNU General Public License as
//	published by the Free Software Foundation.  A copy of this license is
//	included with this software distribution in the file COPYING.  If you
//	do not have a copy, you may obtain a copy by writing to the Free
//	Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
//
//	This software is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details
/////////////////////////////////////////////////////////////////////////////
// Change Log
//
// Date          Developer             Changes
//
// 24 Jul 2000   John Adcock           changed to windows Ini file functions
//
/////////////////////////////////////////////////////////////////////////////

#include "settings.h"

void LoadSettingsFromIni(LPSTR Name)
{
	char szIniFile[MAX_PATH];
	char szKey[128];
	int i;

	GetCurrentDirectory(MAX_PATH, szIniFile);
	strcat(szIniFile, "\\dTV.ini");

	emstartx = GetPrivateProfileInt("MainWindow", "StartLeft", 10, szIniFile);
	emstarty = GetPrivateProfileInt("MainWindow", "StartTop", 10, szIniFile);
	emsizex = GetPrivateProfileInt("MainWindow", "StartWidth", 754, szIniFile);
	emsizey = GetPrivateProfileInt("MainWindow", "StartHeight", 521, szIniFile);
	Res_X = GetPrivateProfileInt("MainWindow", "ResX", 0, szIniFile);
	Res_Y = GetPrivateProfileInt("MainWindow", "ResY", 0, szIniFile);
	bAlwaysOnTop = (GetPrivateProfileInt("MainWindow", "AlwaysOnTop", 0, szIniFile) != 0);

	pgstartx = GetPrivateProfileInt("ProgList", "StartLeft", -1, szIniFile);
	pgstarty = GetPrivateProfileInt("ProgList", "StartTop", -1, szIniFile);
	pgsizex = GetPrivateProfileInt("ProgList", "StartWidth", -1, szIniFile);
	pgsizey = GetPrivateProfileInt("ProgList", "StartHeight", -1, szIniFile);
	for(i = 0; i < 15; i++)
	{
		sprintf(szKey, "LISTFIELD_%d_ID", i + 1);
		ButtonList[i].FeldId = GetPrivateProfileInt("ProgList", szKey, 0, szIniFile);
		sprintf(szKey, "LISTFIELD_%d_LENGTH", i + 1);
		ButtonList[i].x = GetPrivateProfileInt("ProgList", szKey, 0, szIniFile);
	}

	PriorClassId = GetPrivateProfileInt("Threads", "ProcessPriority", 0, szIniFile);
	ThreadClassId = GetPrivateProfileInt("Threads", "ThreadPriority", 1, szIniFile);
	MainProzessor = GetPrivateProfileInt("Threads", "WindowProcessor", 0, szIniFile);
	VBIProzessor = GetPrivateProfileInt("Threads", "VBIProcessor", 0, szIniFile);
	AusgabeProzessor = GetPrivateProfileInt("Threads", "DecodeProcessor", 0, szIniFile);

	bDisplayStatusBar = (GetPrivateProfileInt("Show", "StatusBar", 0, szIniFile) != 0);
	Show_Menu = (GetPrivateProfileInt("Show", "Menu", 1, szIniFile) != 0);
	Toggle_WithOut_Frame = (GetPrivateProfileInt("Show", "NoFrame", 0, szIniFile) != 0);

	VBI_Flags = 0;
	if(GetPrivateProfileInt("VBI", "VT", 0, szIniFile) != 0)
	{
		VBI_Flags += VBI_VT;
	}
	if(GetPrivateProfileInt("VBI", "IC", 0, szIniFile) != 0)
	{
		VBI_Flags += VBI_IC;
	}
	if(GetPrivateProfileInt("VBI", "VPS", 0, szIniFile) != 0)
	{
		VBI_Flags += VBI_VPS;
	}

	i = GetCurrentDirectory(sizeof(IC_BASE_DIR), IC_BASE_DIR);
	strcat(IC_BASE_DIR, "\\I_Cast");
	GetPrivateProfileString("Files", "VBIDir", IC_BASE_DIR, IC_BASE_DIR, MAX_PATH, szIniFile);

	i = GetCurrentDirectory(sizeof(VD_DIR), VD_DIR);
	strcat(VD_DIR, "\\VideoDat");
	GetPrivateProfileString("Files", "VDDir", VD_DIR, VD_DIR, MAX_PATH, szIniFile);
	GetPrivateProfileString("Files", "VDFilename", "VD-RAW.Dat", VDat.RawName, MAX_PATH, szIniFile);
	VD_RAW = (GetPrivateProfileInt("Files", "VDRaw", 0, szIniFile) != 0);


	InitialLow  = GetPrivateProfileInt("Show", "BlackThreshold", 45, szIniFile);
	
	CardType = GetPrivateProfileInt("Hardware", "CardType", 0, szIniFile);
	VideoSource = GetPrivateProfileInt("Hardware", "VideoSource", 1, szIniFile);
	AudioSource = GetPrivateProfileInt("Hardware", "AudioSource", 4, szIniFile);
	TunerType = GetPrivateProfileInt("Hardware", "TunerType", 0, szIniFile); 
	TVTYPE = GetPrivateProfileInt("Hardware", "TVType", 0, szIniFile); 
	InitialHue = GetPrivateProfileInt("Hardware", "InitialHue", 0, szIniFile); 
	InitialContrast = GetPrivateProfileInt("Hardware", "InitialContrast", 0xd8, szIniFile); 
	InitialBrightness = GetPrivateProfileInt("Hardware", "InitialBrightness", 0, szIniFile); 
	InitialSaturationU = GetPrivateProfileInt("Hardware", "InitialSaturationU", 0xfe, szIniFile); 
	InitialSaturationV = GetPrivateProfileInt("Hardware", "InitialSaturationV", 0xb4, szIniFile); 
	InitialIFORM = GetPrivateProfileInt("Hardware", "InitialIFORM", 0, szIniFile); 
	Tuners[8].thresh1 = GetPrivateProfileInt("Hardware", "TunerThreshold1", 0, szIniFile); 
	Tuners[8].thresh2 = GetPrivateProfileInt("Hardware", "TunerThreshold2", 0, szIniFile); 
	Tuners[8].VHF_L = GetPrivateProfileInt("Hardware", "TunerVHF_L", 0, szIniFile); 
	Tuners[8].VHF_H = GetPrivateProfileInt("Hardware", "TunerVHF_H", 0, szIniFile); 
	Tuners[8].UHF = GetPrivateProfileInt("Hardware", "TunerUHF", 0, szIniFile); 
	Tuners[8].config = GetPrivateProfileInt("Hardware", "TunerConfig", 0, szIniFile); 
	Tuners[8].I2C = GetPrivateProfileInt("Hardware", "TunerI2C", 0, szIniFile); 
	Tuners[8].IFPCoff = GetPrivateProfileInt("Hardware", "TunerIFPCoff", 0, szIniFile); 

	ManuellAudio[0] = GetPrivateProfileInt("Hardware", "GPIO_OUT_EN", 0, szIniFile); 
	ManuellAudio[1] = GetPrivateProfileInt("Hardware", "GPIO_DATA_TUNER", 0, szIniFile);  
	ManuellAudio[2] = GetPrivateProfileInt("Hardware", "GPIO_DATA_RADIO", 0, szIniFile);  
	ManuellAudio[3] = GetPrivateProfileInt("Hardware", "GPIO_DATA_EXTERN", 0, szIniFile);  
	ManuellAudio[4] = GetPrivateProfileInt("Hardware", "GPIO_DATA_INTERN", 0, szIniFile);  
	ManuellAudio[5] = GetPrivateProfileInt("Hardware", "GPIO_DATA_OUT", 0, szIniFile);  
	ManuellAudio[6] = GetPrivateProfileInt("Hardware", "GPIO_DATA_IN", 0, szIniFile);  
	ManuellAudio[7] = GetPrivateProfileInt("Hardware", "GPIO_REG_INP", 0, szIniFile);  

	INIT_PLL = GetPrivateProfileInt("Hardware", "Init_PLL", 0, szIniFile);  
	
	USE_DX_LOCK = (GetPrivateProfileInt("Show", "UseDXLocking", 0, szIniFile) != 0);  
	USETUNER = (GetPrivateProfileInt("Show", "UseTuner", 1, szIniFile) != 0);  
	USECARD = (GetPrivateProfileInt("Show", "UseCard", 1, szIniFile) != 0);  
	Capture_Video = (GetPrivateProfileInt("Show", "CaptureVideo", 1, szIniFile) != 0);  
	Capture_VBI = (GetPrivateProfileInt("Show", "CaptureVBI", 1, szIniFile) != 0);  
	InitialProg = GetPrivateProfileInt("Show", "LastProgram", 0, szIniFile);

	LNB.Diseq = (GetPrivateProfileInt("Sound", "DiscEqu", 0, szIniFile) != 0);  

	for(i = 0; i < 4; i++)
	{
		sprintf(szKey, "LNB%d_MinFreq", i + 1);
		LNB.Anschluss[i].MinFreq = GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].MinFreq, szIniFile);
		sprintf(szKey, "LNB%d_MaxFreq", i + 1);
		LNB.Anschluss[i].MaxFreq = GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].MaxFreq, szIniFile);
		sprintf(szKey, "LNB%d_LofLow", i + 1);
		LNB.Anschluss[i].LofLow = GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].LofLow, szIniFile);
		sprintf(szKey, "LNB%d_LofHigh", i + 1);
		LNB.Anschluss[i].LofHigh = GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].LofHigh, szIniFile);
		sprintf(szKey, "LNB%d_SwitchFreq", i + 1);
		LNB.Anschluss[i].SwitchFreq = GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].SwitchFreq, szIniFile);
		sprintf(szKey, "LNB%d_Power", i + 1);
		LNB.Anschluss[i].Power = (GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].Power, szIniFile) != 0);
		sprintf(szKey, "LNB%d_Switch22khz", i + 1);
		LNB.Anschluss[i].Switch22khz = (GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].Switch22khz, szIniFile) != 0);
		sprintf(szKey, "LNB%d_SwitchFreq", i + 1);
		LNB.Anschluss[i].SwitchFreq = GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].SwitchFreq, szIniFile);
		sprintf(szKey, "LNB%d_Use", i + 1);
		LNB.Anschluss[i].Use = (GetPrivateProfileInt("Sound", szKey, LNB.Anschluss[i].Use, szIniFile) != 0);
	}
	
	bSaveSettings = (GetPrivateProfileInt("Show", "SaveSettings", 1, szIniFile) != 0);
	CountryCode = GetPrivateProfileInt("Show", "CountryCode", 1, szIniFile);
	ColourFormat = GetPrivateProfileInt("Show", "ColorFormat", 4, szIniFile);

	i = GetCurrentDirectory(sizeof(VT_BASE_DIR), VT_BASE_DIR);
	strcat(VT_BASE_DIR, "\\VideoText");
	GetPrivateProfileString("VT", "VTDir", VT_BASE_DIR, VT_BASE_DIR, MAX_PATH, szIniFile);
	VT_ALWAYS_EXPORT = (GetPrivateProfileInt("VT", "VTAlwayExport", 0, szIniFile) != 0);
	VT_NL = (GetPrivateProfileInt("VT", "VT_NL", 0, szIniFile) != 0);
	VT_HEADERS = (GetPrivateProfileInt("VT", "VT_Headers", 1, szIniFile) != 0);
	VT_STRIPPED = (GetPrivateProfileInt("VT", "VT_Stripped", 1, szIniFile) != 0);
	VT_REVEAL = (GetPrivateProfileInt("VT", "VT_Reveal", 0, szIniFile) != 0);

	for(i = 0; i < 9; i++)
	{
		sprintf(szKey, "Color%d", i + 1);
		VTColourTable[i] = GetPrivateProfileInt("VT", szKey, VTColourTable[i], szIniFile);
	}
	
	MSPMode = GetPrivateProfileInt("MSP", "MSPMode", 3, szIniFile);	
	MSPMajorMode = GetPrivateProfileInt("MSP", "MSPMajorMode", 0, szIniFile);	
	MSPMinorMode = GetPrivateProfileInt("MSP", "MSPMinorMode", 0, szIniFile);	
	MSPStereo = GetPrivateProfileInt("MSP", "MSPStereo", 0, szIniFile);	
	AutoStereoSelect = (GetPrivateProfileInt("MSP", "MSPAutoStereo", 1, szIniFile) != 0);	
	InitialVolume = GetPrivateProfileInt("MSP", "Volume", 1000, szIniFile);	
	InitialSpatial = GetPrivateProfileInt("MSP", "Spatial", 0, szIniFile);	
	InitialLoudness = GetPrivateProfileInt("MSP", "Loudness", 0, szIniFile);	
	InitialBass = GetPrivateProfileInt("MSP", "Bass", 0, szIniFile);	
	InitialTreble = GetPrivateProfileInt("MSP", "Treble", 0, szIniFile);	
	InitialBalance = GetPrivateProfileInt("MSP", "Balance", 0, szIniFile);	
	InitialSuperBass = (GetPrivateProfileInt("MSP", "SuperBass", 0, szIniFile) != 0);	

	for(i = 0; i < 5; i++)
	{
		sprintf(szKey, "Equalizer%d", i + 1);
		InitialEqualizer[i] = GetPrivateProfileInt("MSP", szKey, 0, szIniFile);
	}

	USE_MIXER = (GetPrivateProfileInt("Mixer", "UseMixer", 0, szIniFile) != 0);	
	MIXER_LINKER_KANAL = GetPrivateProfileInt("Mixer", "VolLeftChannel", -1, szIniFile);
	MIXER_RECHTER_KANAL = GetPrivateProfileInt("Mixer", "VolRightChannel", -1, szIniFile); 

	Volume.SoundSystem = GetPrivateProfileInt("Mixer", "VolumeSoundSystem", -1, szIniFile);
	Volume.Destination = GetPrivateProfileInt("Mixer", "VolumeDestination", 0, szIniFile);
	Volume.Connection = GetPrivateProfileInt("Mixer", "VolumeConnection", 0, szIniFile);
	Volume.Control = GetPrivateProfileInt("Mixer", "VolumeControl", 0, szIniFile);

	Mute.SoundSystem = GetPrivateProfileInt("Mixer", "MuteSoundSystem", -1, szIniFile);
	Mute.Destination = GetPrivateProfileInt("Mixer", "MuteDestination", 0, szIniFile);
	Mute.Connection = GetPrivateProfileInt("Mixer", "MuteConnection", 0, szIniFile);
	Mute.Control = GetPrivateProfileInt("Mixer", "MuteControl", 0, szIniFile);

	for(i = 0; i < 64; i++)
	{
		sprintf(szKey, "MixerSettings%d", i + 1);
		MixerLoad[i].MixerAccess.SoundSystem = GetPrivateProfileInt(szKey, "SoundSystem", -1, szIniFile);
		if(MixerLoad[i].MixerAccess.SoundSystem == -1)
		{
			MixerLoad[i].MixerAccess.Destination = 0;
			MixerLoad[i].MixerAccess.Connection = 0;
			MixerLoad[i].MixerAccess.Control = 0;
			MixerLoad[i].MixerValues.Kanal1 = 0;
			MixerLoad[i].MixerValues.Kanal2 = 0;
			MixerLoad[i].MixerValues.Kanal3 = 0;
			MixerLoad[i].MixerValues.Kanal4 = 0;
		}
		else
		{
			MixerLoad[i].MixerAccess.Destination = GetPrivateProfileInt(szKey, "Destination", 0, szIniFile);
			MixerLoad[i].MixerAccess.Connection = GetPrivateProfileInt(szKey, "Connection", 0, szIniFile);
			MixerLoad[i].MixerAccess.Control = GetPrivateProfileInt(szKey, "Control", 0, szIniFile);
			MixerLoad[i].MixerValues.Kanal1 = GetPrivateProfileInt(szKey, "Channel1", 0, szIniFile);
			MixerLoad[i].MixerValues.Kanal2 = GetPrivateProfileInt(szKey, "Channel2", 0, szIniFile);
			MixerLoad[i].MixerValues.Kanal3 = GetPrivateProfileInt(szKey, "Channel3", 0, szIniFile);
			MixerLoad[i].MixerValues.Kanal4 = GetPrivateProfileInt(szKey, "Channel4", 0, szIniFile);
		}
	}
}

void WriteSettingsToIni()
{
	char szIniFile[MAX_PATH];
	char szKey[128];
	int i;

	GetCurrentDirectory(MAX_PATH, szIniFile);
	strcat(szIniFile, "\\dTV.ini");

	WritePrivateProfileInt("MainWindow", "StartLeft", emstartx, szIniFile);
	WritePrivateProfileInt("MainWindow", "StartTop", emstarty, szIniFile);
	WritePrivateProfileInt("MainWindow", "StartWidth", emsizex, szIniFile);
	WritePrivateProfileInt("MainWindow", "StartHeight", emsizey, szIniFile);
	WritePrivateProfileInt("MainWindow", "ResX", Res_X, szIniFile);
	WritePrivateProfileInt("MainWindow", "ResY", Res_Y, szIniFile);
	WritePrivateProfileInt("MainWindow", "AlwaysOnTop", bAlwaysOnTop, szIniFile);

	WritePrivateProfileInt("ProgList", "StartLeft", pgstartx, szIniFile);
	WritePrivateProfileInt("ProgList", "StartTop", pgstarty, szIniFile);
	WritePrivateProfileInt("ProgList", "StartWidth", pgsizex, szIniFile);
	WritePrivateProfileInt("ProgList", "StartHeight", pgsizey, szIniFile);
	for(i = 0; i < 15; i++)
	{
		sprintf(szKey, "LISTFIELD_%d_ID", i + 1);
		WritePrivateProfileInt("ProgList", szKey, ButtonList[i].FeldId, szIniFile);
		sprintf(szKey, "LISTFIELD_%d_LENGTH", i + 1);
		WritePrivateProfileInt("ProgList", szKey, ButtonList[i].x, szIniFile);
	}

	WritePrivateProfileInt("Threads", "ProcessPriority", PriorClassId, szIniFile);
	WritePrivateProfileInt("Threads", "ThreadPriority", ThreadClassId, szIniFile);
	WritePrivateProfileInt("Threads", "WindowProcessor", MainProzessor, szIniFile);
	WritePrivateProfileInt("Threads", "VBIProcessor", VBIProzessor, szIniFile);
	WritePrivateProfileInt("Threads", "DecodeProcessor", AusgabeProzessor, szIniFile);

	WritePrivateProfileInt("Show", "StatusBar", bDisplayStatusBar, szIniFile);
	WritePrivateProfileInt("Show", "Menu", Show_Menu, szIniFile);
	WritePrivateProfileInt("Show", "NoFrame", Toggle_WithOut_Frame, szIniFile);

	WritePrivateProfileInt("VBI", "VT", VBI_Flags & VBI_VT, szIniFile);
	WritePrivateProfileInt("VBI", "IC", VBI_Flags & VBI_IC, szIniFile);
	WritePrivateProfileInt("VBI", "VPS", VBI_Flags & VBI_VPS, szIniFile);

	WritePrivateProfileString("Files", "VBIDir", IC_BASE_DIR, szIniFile);
	WritePrivateProfileString("Files", "VDDir", VD_DIR, szIniFile);
	WritePrivateProfileString("Files", "VDFilename", VDat.RawName, szIniFile);
	WritePrivateProfileInt("Files", "VDRaw", VD_RAW, szIniFile);

	WritePrivateProfileInt("Show", "BlackThreshold", InitialLow, szIniFile);
	
	WritePrivateProfileInt("Hardware", "CardType", CardType, szIniFile);
	WritePrivateProfileInt("Hardware", "VideoSource", VideoSource, szIniFile);
	WritePrivateProfileInt("Hardware", "AudioSource", AudioSource, szIniFile);
	WritePrivateProfileInt("Hardware", "TunerType", TunerType, szIniFile); 
	WritePrivateProfileInt("Hardware", "TVType", TVTYPE, szIniFile); 
	WritePrivateProfileInt("Hardware", "InitialHue", InitialHue, szIniFile); 
	WritePrivateProfileInt("Hardware", "InitialContrast", InitialContrast, szIniFile); 
	WritePrivateProfileInt("Hardware", "InitialBrightness", InitialBrightness, szIniFile); 
	WritePrivateProfileInt("Hardware", "InitialSaturationU", InitialSaturationU, szIniFile); 
	WritePrivateProfileInt("Hardware", "InitialSaturationV", InitialSaturationV, szIniFile); 
	WritePrivateProfileInt("Hardware", "InitialIFORM", InitialIFORM, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerThreshold1", Tuners[8].thresh1, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerThreshold2", Tuners[8].thresh2, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerVHF_L", Tuners[8].VHF_L, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerVHF_H", Tuners[8].VHF_H, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerUHF", Tuners[8].UHF, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerConfig", Tuners[8].config, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerI2C", Tuners[8].I2C, szIniFile); 
	WritePrivateProfileInt("Hardware", "TunerIFPCoff", Tuners[8].IFPCoff, szIniFile); 

	WritePrivateProfileInt("Hardware", "GPIO_OUT_EN", ManuellAudio[0], szIniFile); 
	WritePrivateProfileInt("Hardware", "GPIO_DATA_TUNER", ManuellAudio[1], szIniFile);  
	WritePrivateProfileInt("Hardware", "GPIO_DATA_RADIO", ManuellAudio[2], szIniFile);  
	WritePrivateProfileInt("Hardware", "GPIO_DATA_EXTERN", ManuellAudio[3], szIniFile);  
	WritePrivateProfileInt("Hardware", "GPIO_DATA_INTERN", ManuellAudio[4], szIniFile);  
	WritePrivateProfileInt("Hardware", "GPIO_DATA_OUT", ManuellAudio[5], szIniFile);  
	WritePrivateProfileInt("Hardware", "GPIO_DATA_IN", ManuellAudio[6], szIniFile);  
	WritePrivateProfileInt("Hardware", "GPIO_REG_INP", ManuellAudio[7], szIniFile);  

	WritePrivateProfileInt("Hardware", "Init_PLL", INIT_PLL, szIniFile);  
	
	WritePrivateProfileInt("Show", "UseDXLocking", USE_DX_LOCK, szIniFile);
	WritePrivateProfileInt("Show", "UseTuner", USETUNER, szIniFile); 
	WritePrivateProfileInt("Show", "UseCard", USECARD, szIniFile);
	WritePrivateProfileInt("Show", "CaptureVideo", Capture_Video, szIniFile);
	WritePrivateProfileInt("Show", "CaptureVBI", Capture_VBI, szIniFile);
	WritePrivateProfileInt("Show", "LastProgram", InitialProg, szIniFile);

	WritePrivateProfileInt("Sound", "DiscEqu", LNB.Diseq, szIniFile);

	for(i = 0; i < 4; i++)
	{
		sprintf(szKey, "LNB%d_MinFreq", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].MinFreq, szIniFile);
		sprintf(szKey, "LNB%d_MaxFreq", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].MaxFreq, szIniFile);
		sprintf(szKey, "LNB%d_LofLow", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].LofLow, szIniFile);
		sprintf(szKey, "LNB%d_LofHigh", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].LofHigh, szIniFile);
		sprintf(szKey, "LNB%d_SwitchFreq", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].SwitchFreq, szIniFile);
		sprintf(szKey, "LNB%d_Power", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].Power, szIniFile);
		sprintf(szKey, "LNB%d_Switch22khz", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].Switch22khz, szIniFile);
		sprintf(szKey, "LNB%d_SwitchFreq", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].SwitchFreq, szIniFile);
		sprintf(szKey, "LNB%d_Use", i + 1);
		WritePrivateProfileInt("Sound", szKey, LNB.Anschluss[i].Use, szIniFile);
	}
	
	WritePrivateProfileInt("Show", "SaveSettings", bSaveSettings, szIniFile);
	WritePrivateProfileInt("Show", "CountryCode", CountryCode, szIniFile);
	WritePrivateProfileInt("Show", "ColorFormat", ColourFormat, szIniFile);

	WritePrivateProfileString("VT", "VTDir", VT_BASE_DIR, szIniFile);
	WritePrivateProfileInt("VT", "VTAlwayExport", VT_ALWAYS_EXPORT, szIniFile);
	WritePrivateProfileInt("VT", "VT_NL", VT_NL, szIniFile);
	WritePrivateProfileInt("VT", "VT_Headers", VT_HEADERS, szIniFile);
	WritePrivateProfileInt("VT", "VT_Stripped", VT_STRIPPED, szIniFile);
	WritePrivateProfileInt("VT", "VT_Reveal", VT_REVEAL, szIniFile);

	for(i = 0; i < 9; i++)
	{
		sprintf(szKey, "Color%d", i + 1);
		WritePrivateProfileInt("VT", szKey, VTColourTable[i], szIniFile);
	}
	
	WritePrivateProfileInt("MSP", "MSPMode", MSPMode, szIniFile);	
	WritePrivateProfileInt("MSP", "MSPMajorMode", MSPMajorMode, szIniFile);	
	WritePrivateProfileInt("MSP", "MSPMinorMode", MSPMinorMode, szIniFile);	
	WritePrivateProfileInt("MSP", "MSPStereo", MSPStereo, szIniFile);	
	WritePrivateProfileInt("MSP", "MSPAutoStereo", AutoStereoSelect, szIniFile);	
	WritePrivateProfileInt("MSP", "Volume", InitialVolume, szIniFile);	
	WritePrivateProfileInt("MSP", "Spatial", InitialSpatial, szIniFile);	
	WritePrivateProfileInt("MSP", "Loudness", InitialLoudness, szIniFile);	
	WritePrivateProfileInt("MSP", "Bass", InitialBass, szIniFile);	
	WritePrivateProfileInt("MSP", "Treble", InitialTreble, szIniFile);	
	WritePrivateProfileInt("MSP", "Balance", InitialBalance, szIniFile);	
	WritePrivateProfileInt("MSP", "SuperBass", InitialSuperBass, szIniFile);	

	for(i = 0; i < 5; i++)
	{
		sprintf(szKey, "Equalizer%d", i + 1);
		WritePrivateProfileInt("MSP", szKey, InitialEqualizer[i], szIniFile);
	}

	WritePrivateProfileInt("Mixer", "UseMixer", USE_MIXER, szIniFile);	
	WritePrivateProfileInt("Mixer", "VolLeftChannel", MIXER_LINKER_KANAL, szIniFile);
	WritePrivateProfileInt("Mixer", "VolRightChannel", MIXER_RECHTER_KANAL, szIniFile); 

	WritePrivateProfileInt("Mixer", "VolumeSoundSystem", Volume.SoundSystem, szIniFile);
	WritePrivateProfileInt("Mixer", "VolumeDestination", Volume.Destination, szIniFile);
	WritePrivateProfileInt("Mixer", "VolumeConnection", Volume.Connection, szIniFile);
	WritePrivateProfileInt("Mixer", "VolumeControl", Volume.Control, szIniFile);

	WritePrivateProfileInt("Mixer", "MuteSoundSystem", Mute.SoundSystem, szIniFile);
	WritePrivateProfileInt("Mixer", "MuteDestination", Mute.Destination, szIniFile);
	WritePrivateProfileInt("Mixer", "MuteConnection", Mute.Connection, szIniFile);
	WritePrivateProfileInt("Mixer", "MuteControl", Mute.Control, szIniFile);

	for(i = 0; i < 64; i++)
	{
		sprintf(szKey, "MixerSettings%d", i + 1);
		if(MixerLoad[i].MixerAccess.SoundSystem != -1)
		{
			WritePrivateProfileInt(szKey, "SoundSystem", MixerLoad[i].MixerAccess.SoundSystem, szIniFile);
			WritePrivateProfileInt(szKey, "Destination", MixerLoad[i].MixerAccess.Destination, szIniFile);
			WritePrivateProfileInt(szKey, "Connection", MixerLoad[i].MixerAccess.Connection, szIniFile);
			WritePrivateProfileInt(szKey, "Control", MixerLoad[i].MixerAccess.Control, szIniFile);
			WritePrivateProfileInt(szKey, "Channel1", MixerLoad[i].MixerValues.Kanal1, szIniFile);
			WritePrivateProfileInt(szKey, "Channel2", MixerLoad[i].MixerValues.Kanal2, szIniFile);
			WritePrivateProfileInt(szKey, "Channel3", MixerLoad[i].MixerValues.Kanal3, szIniFile);
			WritePrivateProfileInt(szKey, "Channel4", MixerLoad[i].MixerValues.Kanal4, szIniFile);
		}
	}
}

void WritePrivateProfileInt(LPCTSTR lpAppName,  LPCTSTR lpKeyName,  int nValue, LPCTSTR lpFileName)
{
	char szValue[128];
	sprintf(szValue, "%d", nValue);
	WritePrivateProfileString(lpAppName,  lpKeyName,  szValue, lpFileName);
}
