/////////////////////////////////////////////////////////////////////////////
// dTV.h
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2000 John Adcock.  All rights reserved.
/////////////////////////////////////////////////////////////////////////////
//
//	This file is subject to the terms of the GNU General Public License as
//	published by the Free Software Foundation.  A copy of this license is
//	included with this software distribution in the file COPYING.  If you
//	do not have a copy, you may obtain a copy by writing to the Free
//	Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
//
//	This software is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details
/////////////////////////////////////////////////////////////////////////////
//
// This software was based on Multidec 5.6 Those portions are
// Copyright (C) 1999/2000 Espresso (echter_espresso@hotmail.com)
//
/////////////////////////////////////////////////////////////////////////////
// Change Log
//
// Date          Developer             Changes
//
// 24 Jul 2000   John Adcock           Original Release
//                                     Translated most code from German
//                                     Combined Header files
//                                     Cut out all decoding
//                                     Cut out digital hardware stuff
//
/////////////////////////////////////////////////////////////////////////////

#include "other.h"
#include "bt848.h"
#include "mixerdev.h"
#include "vt.h"
#include "dTV.h"
#include "settings.h"
#include "ProgramList.h"
#include "Dialogs.h"
#include "OutThreads.h"

HWND hwndStatusBar;
HWND hwndTextField;
HWND hwndPalField;
HWND hwndKeyField;
HWND hwndFPSField;
HWND hwndAudioField;

BOOL bDoResize = FALSE;

struct TVTDialog VTDialog[MAXVTDIALOG];

BOOL VTLarge=TRUE;

int CurrentProgramm;

HWND VThWnd;

int PriorClassId;
int ThreadClassId = 1;

SYSTEM_INFO SysInfo;

struct TCountries Countries[35];

unsigned long freq;
char Typ;
unsigned int srate;         

struct TBL ButtonList[15];

BYTE  *pDisplay[5] =  { NULL,NULL,NULL,NULL,NULL  };

int MoveXDist=-1;
int MoveYDist=-1;


BITMAPINFO          *VTCharSetLarge                    = NULL;
BITMAPINFO          *VTCharSetSmall                    = NULL;
HBITMAP             BirneRot;
HBITMAP             BirneGruen;
BITMAPINFO          *VTScreen[MAXVTDIALOG];

long WStyle;

BOOL Show_Menu=TRUE;
HMENU hMenu;
HANDLE          hAccel;

HWND SplashWnd;

struct TPacket30 Packet30;


char ChannelString[10];

char BTTyp[30];
char MSPStatus[30];
char TunerStatus[30];

int LastFrame;


int CurrentX,CurrentY;
int Res_X,Res_Y;

unsigned char *pBurstLine[5];

int FORMAT_MASK = 0x0F;
int PalFormat = 0;

int  nPALplusZeile  = -10;
int  nPALplusData   =  0;

BOOL  BlackSet[288];


BYTE INIT_PLL = 0; 

int CurrentFrame=0;

BOOL bHardwareFound = FALSE;

LOGFONT lf = {16,0,0,0,400,0,0,0,0,0,0,0,0,"MS Sans Serif"};   

int BeforeVD=0;

int WriteIndex=1;


BOOL USE_MIXER=FALSE;
int  MIXER_LINKER_KANAL=-1;
int  MIXER_RECHTER_KANAL=-1;
int MixerVolumeStep=-1;
int MixerVolumeMax=-1;

// Fantasio for Secam-Extensions
short NullTable[4] = {8192, 0, 0, 8192};

int InitialProg=-1;

int AnzahlProzessor=1;
int MainProzessor=0;
int VBIProzessor=0;
int AusgabeProzessor=0;
int ProzessorMask;


BOOL CShowCursor = TRUE;

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wc;
	HINSTANCE statusbar;
	MSG msg;
	HGLOBAL hGlobal;
	HWND hPrevWindow;
	int i;

	hInst = hInstance;

	// if we are already runninmg then start up old version
	hPrevWindow = FindWindow((LPCTSTR) "dTV", (LPCTSTR) "dTV");
	if (hPrevWindow != NULL)
	{
		SetFocus(hPrevWindow);
		SetActiveWindow(hPrevWindow);
		SetForegroundWindow(hPrevWindow);
		return FALSE;
	}

	SplashWnd = CreateDialog(hInst, "SPLASHBOX", NULL, SplashProc);
	SetWindowPos(SplashWnd, HWND_TOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);

	LoadSettingsFromIni();

	if (strlen(IC_BASE_DIR) > 0)
	{
		i = (int) CreateDirectory(IC_BASE_DIR, NULL);
	}
	if (strlen(VD_DIR) > 0)
	{
		i = (int) CreateDirectory(VD_DIR, NULL);
	}
	if (strlen(VT_BASE_DIR) > 0)
	{
		i = (int) CreateDirectory(VT_BASE_DIR, NULL);
	}

	wc.style = 0;
	wc.lpfnWndProc = (WNDPROC) MainWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = sizeof(LONG);
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(hInstance, "DTVICON");
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = CreateSolidBrush(0);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = "dTV";

	if (!RegisterClass(&wc))
	{
		return FALSE;
	}
	hMenu = LoadMenu(hInstance, "ANALOGMENU");
	hWnd = CreateWindow("dTV", "dTV", WS_OVERLAPPEDWINDOW, emstartx, emstarty, emsizex, emsizey, NULL, NULL, hInstance, NULL);

	if (!hWnd)
		return (FALSE);

	statusbar = hInst;
	if (!InitStatusBar(statusbar))
	{
		return FALSE;
	}

	if (CreateStatusBar(hWnd, statusbar, ID_STATUSBAR))
	{
		hwndTextField = AddStatusField(statusbar, ID_TEXTFIELD, 110, 0, FALSE);
		hwndAudioField = AddStatusField(statusbar, ID_AUDIOFIELD, 110, 0, FALSE);
		hwndPalField = AddStatusField(statusbar, ID_CODEFIELD, 110, 0, FALSE);
		hwndKeyField = AddStatusField(statusbar, ID_KENNUNGFFIELD, 90, 50, FALSE);
		hwndFPSField = AddStatusField(statusbar, ID_FPSFIELD, 45, 45, TRUE);
	}
	else
	{
		return FALSE;
	}

	AdjustStatusBar(hWnd);

	if (bDisplayStatusBar == FALSE)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_STATUSBAR, MF_UNCHECKED);
		ShowWindow(hwndStatusBar, SW_HIDE);
	}
	else
	{
		CheckMenuItem(GetMenu(hWnd), IDM_STATUSBAR, MF_CHECKED);
	}

	hGlobal = LoadResource(hInst, FindResource(hInst, "VTCHARLARGE", RT_BITMAP));
	VTCharSetLarge = (BITMAPINFO *) LockResource(hGlobal);
	hGlobal = LoadResource(hInst, FindResource(hInst, "VTCHARSMALL", RT_BITMAP));
	VTCharSetSmall = (BITMAPINFO *) LockResource(hGlobal);

	BirneRot = LoadBitmap(hInst, "BROT");
	BirneGruen = LoadBitmap(hInst, "BGRUEN");
	currFont = CreateFontIndirect(&lf);

	ShowWindow(hWnd, nCmdShow);
	PostMessage(hWnd, WM_SIZE, SIZENORMAL, MAKELONG(emsizex, emsizey));
	if (!(hAccel = LoadAccelerators(hInstance, "ANALOGACCEL")))
	{
		(void) MessageBox(GetFocus(), "Accelerators not Loaded", "Error", MB_OK);
	}

	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(hWnd, hAccel, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	DeleteObject(currFont);
	DeleteObject(VTCharSetLarge);
	DeleteObject(VTCharSetSmall);
	DeleteObject(BirneRot);
	DeleteObject(BirneGruen);

	return (msg.wParam);
}

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages

    MESSAGES:

        WM_COMMAND    - application menu (About dialog box)
        WM_CREATE     - create window and objects
        WM_PAINT      - update window, draw objects
        WM_DESTROY    - destroy window

    COMMENTS:

        Handles to the objects you will use are obtained when the WM_CREATE
        message is received, and deleted when the WM_DESTROY message is
        received.  The actual drawing is done whenever a WM_PAINT message is
        received.

****************************************************************************/
LONG APIENTRY MainWndProc(HWND hWnd, UINT message, UINT wParam, LONG lParam)
{
	char Text[128];
	char Text1[128];
	int i, j, k;
	static BOOL Capture_Pause = FALSE;
	RECT rScreen;

	switch (message)
	{

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDM_CLOSE_VT:
			for (i = 0; i < MAXVTDIALOG; i++)
			{
				if (VTDialog[i].Dialog != NULL)
					SendMessage(VTDialog[i].Dialog, WM_COMMAND, IDCANCEL, 0);
			}
			SetFocus(hWnd);
			break;

		case IDM_VT_PAGE_MINUS:
			for (i = 0; i < MAXVTDIALOG; i++)
			{
				if (VTDialog[i].Dialog != NULL)
				{
					j = Get_Dialog_Slot(VTDialog[i].Dialog);
					if (VTDialog[j].Page > 100)
					{
						SetDlgItemInt(VTDialog[j].Dialog, IDC_EDIT1, VTDialog[j].Page - 1, FALSE);
						VTDialog[j].PageChange = TRUE;
					}
				}
			}
			return (TRUE);

		case IDM_VT_PAGE_PLUS:
			for (i = 0; i < MAXVTDIALOG; i++)
			{
				if (VTDialog[i].Dialog != NULL)
				{
					j = Get_Dialog_Slot(VTDialog[i].Dialog);
					if (VTDialog[j].Page < 899)
					{
						SetDlgItemInt(VTDialog[j].Dialog, IDC_EDIT1, VTDialog[j].Page + 1, FALSE);
						VTDialog[j].PageChange = TRUE;
					}
				}
			}
			return (TRUE);

		case IDM_VT_PAGE_UP:
			for (i = 0; i < MAXVTDIALOG; i++)
			{
				if (VTDialog[i].Dialog != NULL)
				{
					j = Get_Dialog_Slot(VTDialog[i].Dialog);
					k = VTDialog[j].SubPage;
					if (VTFrame[VTDialog[j].FramePos].SubCount == 0)
						return (TRUE);
					k--;
					while ((k >= 0) && (VTFrame[VTDialog[j].FramePos].SubPage[k].Fill == FALSE))
						k--;
					if (k < 0)
						k = VTFrame[VTDialog[j].FramePos].SubCount - 1;	//DF:i
					while ((k >= 0) && (VTFrame[VTDialog[j].FramePos].SubPage[k].Fill == FALSE))
						k--;
					if (k < 0)
						return (TRUE);

					if ((k >= 0) && (VTFrame[VTDialog[j].FramePos].SubPage[k].Fill == TRUE))
						VTDialog[j].SubPage = k;	//DF: else...
					SetDlgItemInt(VTDialog[j].Dialog, IDC_EDIT1, VTDialog[j].Page, FALSE);
				}
			}
			return (TRUE);

		case IDM_VT_PAGE_DOWN:
			for (i = 0; i < MAXVTDIALOG; i++)
			{
				if (VTDialog[i].Dialog != NULL)
				{
					j = Get_Dialog_Slot(VTDialog[i].Dialog);
					k = VTDialog[j].SubPage;
					if (VTFrame[VTDialog[j].FramePos].SubCount == 0)
						return (TRUE);
					k++;
					while ((k <= VTFrame[VTDialog[j].FramePos].SubCount - 1) && (VTFrame[VTDialog[j].FramePos].SubPage[k].Fill == FALSE))
						k++;
					if (k >= VTFrame[VTDialog[j].FramePos].SubCount)
						k = 0;	//DF:i
					while ((k <= VTFrame[VTDialog[j].FramePos].SubCount - 1) && (VTFrame[VTDialog[j].FramePos].SubPage[k].Fill == FALSE))
						k++;
					if (k >= VTFrame[VTDialog[j].FramePos].SubCount)
						return (TRUE);

					//k++;
					//if ( k >= VTFrame[VTDialog[j].FramePos].SubCount ) k=0;
					//while (( k < VTFrame[VTDialog[j].FramePos].SubCount) && ( VTFrame[VTDialog[j].FramePos].SubPage[k].Fill == FALSE )) k++;
					if ((k < VTFrame[VTDialog[j].FramePos].SubCount) && (VTFrame[VTDialog[j].FramePos].SubPage[k].Fill == TRUE))
						VTDialog[j].SubPage = k;
					else
						return (TRUE);
					SetDlgItemInt(VTDialog[j].Dialog, IDC_EDIT1, VTDialog[j].Page, FALSE);
				}
			}
			return (TRUE);

		case IDM_CHANNELPLUS:
			if (USETUNER == FALSE)
				break;
			SetAudioSource(4);

			i = CurrentProgramm + 1;
			CurrentProgramm = -1;
			while (i < MAXPROGS)
			{
				if ((Programm[i].freq != 0) && (ValidModes(Programm[i].Typ) == TRUE))
				{
					CurrentProgramm = i;
					break;
				}
				i++;
			}

			if (CurrentProgramm == -1)
			{
				i = 0;
				while (i < MAXPROGS)
				{
					if ((Programm[i].freq != 0) && (ValidModes(Programm[i].Typ) == TRUE))
					{
						CurrentProgramm = i;
						break;
					}
					i++;
				}
			}

			if (CurrentProgramm >= 0)
			{
				Tuner_SetFrequency(TunerType, MulDiv(Programm[CurrentProgramm].freq * 1000, 16, 1000000));

				if (bDisplayStatusBar == TRUE)
				{
					sprintf(Text, "%04d. %s ", CurrentProgramm + 1, Programm[CurrentProgramm].Name);
					SetWindowText(hwndKeyField, Text);
				}
				VT_ChannelChange();
			}
			SetAudioSource(AudioSource);
			break;

		case IDM_CHANNELMINUS:
			if (USETUNER == FALSE)
				break;
			SetAudioSource(4);
			i = CurrentProgramm - 1;
			CurrentProgramm = -1;
			while (i >= 0)
			{
				if ((Programm[i].freq != 0) && (ValidModes(Programm[i].Typ) == TRUE))
				{
					CurrentProgramm = i;
					break;
				}
				i--;
			}

			if (CurrentProgramm == -1)
			{
				i = MAXPROGS - 1;
				while (i >= 0)
				{
					if ((Programm[i].freq != 0) && (ValidModes(Programm[i].Typ) == TRUE))
					{
						CurrentProgramm = i;
						break;
					}
					i--;
				}
			}

			if (CurrentProgramm >= 0)
			{

				Tuner_SetFrequency(TunerType, MulDiv(Programm[CurrentProgramm].freq * 1000, 16, 1000000));

				if (bDisplayStatusBar == TRUE)
				{
					sprintf(Text, "%04d. %s ", CurrentProgramm + 1, Programm[CurrentProgramm].Name);
					SetWindowText(hwndKeyField, Text);
				}
				VT_ChannelChange();
			}
			SetAudioSource(AudioSource);
			break;

		case IDM_RESET:
			Set_Capture(4);
			Reset_BT_HardWare(hWnd);
			Init_Screen_Struct();
			Set_Capture(5);
			Sleep(100);
			SetAudioSource(AudioSource);
			break;

		case IDM_TOGGLE_MENU:
			Stop_Thread();
			Set_Capture(4);
			if (Show_Menu == TRUE)
			{
				Show_Menu = FALSE;
				bDisplayStatusBar = FALSE;
				ShowWindow(hwndStatusBar, SW_HIDE);
				KillTimer(hWnd, 1);

				WStyle = GetWindowLong(hWnd, GWL_STYLE);
				if (Toggle_WithOut_Frame == TRUE)
					SetWindowLong(hWnd, GWL_STYLE, WS_VISIBLE);
				else
					SetWindowLong(hWnd, GWL_STYLE, WS_VISIBLE | WS_THICKFRAME);
				SetMenu(hWnd, NULL);
			}
			else
			{
				Show_Menu = TRUE;
				bDisplayStatusBar = TRUE;
				ShowWindow(hwndStatusBar, SW_SHOW);
				SetTimer(hWnd, 1, 2500, NULL);
				SetWindowLong(hWnd, GWL_STYLE, WStyle);
				SetMenu(hWnd, hMenu);
			}
			Init_Screen_Struct();
			Set_Capture(5);
			return (TRUE);
			break;

		case IDM_ABOUT:
			DialogBox(hInst, "ABOUT", hWnd, AboutProc);
			break;

		case IDM_BRIGHTNESSPLUS:
			if (InitialBrightness < 128)
				i = InitialBrightness;
			else
				i = -(256 - InitialBrightness);

			if ((i > -127) && (i < 127))
				i++;
			if (i < 0)
				InitialBrightness = 256 + i;
			else
				InitialBrightness = i;
			SetBrightness(InitialBrightness);
			sprintf(Text, "Brightness %d", i);
			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_BRIGHTNESSMINUS:
			if (InitialBrightness < 128)
				i = InitialBrightness;
			else
				i = -(256 - InitialBrightness);
			if ((i > -127) && (i < 127))
				i--;
			if (i < 0)
				InitialBrightness = 256 + i;
			else
				InitialBrightness = i;
			SetBrightness(InitialBrightness);
			sprintf(Text, "Brightness %d", i);
			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_COLORPLUS:
			if ((InitialSaturationU < 255) && (InitialSaturationV < 255))
			{
				InitialSaturationU++;
				InitialSaturationV++;
				sprintf(Text, "Colour U %d V %d", InitialSaturationU, InitialSaturationV);
				if (bDisplayStatusBar == TRUE)
					SetWindowText(hwndTextField, Text);
				SetSaturationU(InitialSaturationU);
				SetSaturationV(InitialSaturationV);
			}
			break;

		case IDM_COLORMINUS:
			if ((InitialSaturationU > 0) && (InitialSaturationV > 0))
			{
				InitialSaturationU--;
				InitialSaturationV--;
				sprintf(Text, "Colour U %d V %d", InitialSaturationU, InitialSaturationV);
				if (bDisplayStatusBar == TRUE)
					SetWindowText(hwndTextField, Text);
				SetSaturationU(InitialSaturationU);
				SetSaturationV(InitialSaturationV);
			}
			break;

		case IDM_KONTRASTPLUS:
			if (InitialContrast < 256)
				InitialContrast++;
			SetContrast(InitialContrast);
			sprintf(Text, "Contrast %d", InitialContrast);
			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_KONTRASTMINUS:
			if (InitialContrast > 0)
				InitialContrast--;
			SetContrast(InitialContrast);
			sprintf(Text, "Contrast %d", InitialContrast);
			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_MUTE:
			if (System_In_Mute == FALSE)
			{
				System_In_Mute = TRUE;
				if (USE_MIXER == FALSE)
				{
					SetAudioSource(4);
					sprintf(Text, "Mute BT");
				}
				if (USE_MIXER == TRUE)
				{
					Mixer_Mute();
					sprintf(Text, "Mute Mixer");
				}
			}
			else
			{
				System_In_Mute = FALSE;
				if (USE_MIXER == FALSE)
				{
					SetAudioSource(AudioSource);
					sprintf(Text, "UnMute BT");
				}
				if (USE_MIXER == TRUE)
				{
					Mixer_UnMute();
					sprintf(Text, "UnMute Mixer");
				}

			}
			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_L_BALANCE:
			if (USE_MIXER == FALSE)
			{
				if (InitialBalance > -127)
					InitialBalance--;
				Audio_SetBalance(InitialBalance);	// -127 - +128
				sprintf(Text, "BT-Balance %d", InitialBalance);
			}
			if (USE_MIXER == TRUE)
			{
				if (MIXER_LINKER_KANAL + MixerVolumeStep <= MixerVolumeMax)
					MIXER_LINKER_KANAL += MixerVolumeStep;
				if (MIXER_RECHTER_KANAL - MixerVolumeStep >= 0)
					MIXER_RECHTER_KANAL -= MixerVolumeStep;
				Mixer_Set_Volume(MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
				sprintf(Text, "Balance L %d R %d", MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
			}

			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_R_BALANCE:
			if (USE_MIXER == FALSE)
			{
				if (InitialBalance < 128)
					InitialBalance++;
				Audio_SetBalance(InitialBalance);	// -127 - +128
				sprintf(Text, "BT-Balance %d", InitialBalance);
			}
			if (USE_MIXER == TRUE)
			{
				if (MIXER_LINKER_KANAL - MixerVolumeStep >= 0)
					MIXER_LINKER_KANAL -= MixerVolumeStep;
				if (MIXER_RECHTER_KANAL + MixerVolumeStep <= MixerVolumeMax)
					MIXER_RECHTER_KANAL += MixerVolumeStep;
				Mixer_Set_Volume(MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
				sprintf(Text, "Balance L %d R %d", MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
			}

			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_VOLUMEPLUS:
			if (USE_MIXER == FALSE)
			{
				if (InitialVolume < 980)
					InitialVolume += 20;
				Audio_SetVolume(InitialVolume);
				sprintf(Text, "BT-Volume %d", InitialVolume);
			}
			if (USE_MIXER == TRUE)
			{
				i = ((MixerVolumeMax / MixerVolumeStep) / 100) * MixerVolumeStep;
				if ((i + MIXER_LINKER_KANAL > MixerVolumeMax) || (i + MIXER_RECHTER_KANAL > MixerVolumeMax))
					i = MixerVolumeStep;
				if (MIXER_LINKER_KANAL + i <= MixerVolumeMax)
					MIXER_LINKER_KANAL += i;
				if (MIXER_RECHTER_KANAL + i <= MixerVolumeMax)
					MIXER_RECHTER_KANAL += i;
				Mixer_Set_Volume(MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
				sprintf(Text, "Volume L %d R %d", MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
			}

			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;
		case IDM_VOLUMEMINUS:
			if (USE_MIXER == FALSE)
			{
				if (InitialVolume > 20)
					InitialVolume -= 20;
				Audio_SetVolume(InitialVolume);
				sprintf(Text, "BT-Volume %d", InitialVolume);
			}
			if (USE_MIXER == TRUE)
			{
				i = ((MixerVolumeMax / MixerVolumeStep) / 100) * MixerVolumeStep;
				if ((MIXER_LINKER_KANAL - i < 0) || (MIXER_RECHTER_KANAL - i < 0))
					i = MixerVolumeStep;
				if (MIXER_LINKER_KANAL - i >= 0)
					MIXER_LINKER_KANAL -= i;
				if (MIXER_RECHTER_KANAL - i >= 0)
					MIXER_RECHTER_KANAL -= i;
				Mixer_Set_Volume(MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
				sprintf(Text, "Volume L %d R %d", MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);

			}

			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndTextField, Text);
			break;

		case IDM_TOGGLECURSOR:
			CShowCursor = !CShowCursor;
			i = ShowCursor(CShowCursor);
			break;

		case IDM_KARTE0:
		case IDM_KARTE1:
		case IDM_KARTE2:
		case IDM_KARTE3:
		case IDM_KARTE4:
		case IDM_KARTE5:
		case IDM_KARTE6:
			CheckMenuItem(GetMenu(hWnd), CardType + 1080, MF_UNCHECKED);
			CardType = wParam - 1080;
			CheckMenuItem(GetMenu(hWnd), CardType + 1080, MF_CHECKED);
			break;
		case IDM_MANUELL_CARD:
			DialogBox(hInst, "CARDTYPE", hWnd, (DLGPROC) CardSettingProc);
			break;

		case IDM_ENDE:
			PostMessage(hWnd, WM_DESTROY, wParam, lParam);
			break;

		case IDM_MSPMODE_3:
		case IDM_MSPMODE_2:
		case IDM_MSPMODE_4:
		case IDM_MSPMODE_5:
		case IDM_MSPMODE_6:
			MSP_SetMode(wParam - 1600);
			break;

		case IDM_MAJOR_CARRIER_0:
		case IDM_MAJOR_CARRIER_1:
		case IDM_MAJOR_CARRIER_2:
		case IDM_MAJOR_CARRIER_3:
			MSP_Set_MajorMinor_Mode(wParam - 1610, MSPMinorMode);
			break;

		case IDM_MINOR_CARRIER_0:
		case IDM_MINOR_CARRIER_1:
		case IDM_MINOR_CARRIER_2:
		case IDM_MINOR_CARRIER_3:
		case IDM_MINOR_CARRIER_4:
		case IDM_MINOR_CARRIER_5:
		case IDM_MINOR_CARRIER_6:
		case IDM_MINOR_CARRIER_7:
			MSP_Set_MajorMinor_Mode(MSPMajorMode, wParam - 1620);
			break;

		case IDM_MSPSTEREO_1:
		case IDM_MSPSTEREO_2:
		case IDM_MSPSTEREO_3:
		case IDM_MSPSTEREO_4:
			MSP_SetStereo(MSPMajorMode, MSPMinorMode, wParam - 1630);
			break;

		case IDM_AUTOSTEREO:
			if (AutoStereoSelect == FALSE)
			{
				AutoStereoSelect = TRUE;
				CheckMenuItem(GetMenu(hWnd), IDM_AUTOSTEREO, MF_CHECKED);

			}
			else
			{
				AutoStereoSelect = FALSE;
				CheckMenuItem(GetMenu(hWnd), IDM_AUTOSTEREO, MF_UNCHECKED);
			}
			break;

		case IDM_AUDIO_0:
		case IDM_AUDIO_1:
		case IDM_AUDIO_2:
		case IDM_AUDIO_3:
		case IDM_AUDIO_4:
		case IDM_AUDIO_5:

			CheckMenuItem(GetMenu(hWnd), AudioSource + 1110, MF_UNCHECKED);
			AudioSource = wParam - 1110;
			Set_Capture(4);
			SetAudioSource(AudioSource);
			Set_Capture(5);
			CheckMenuItem(GetMenu(hWnd), AudioSource + 1110, MF_CHECKED);
			break;

		case IDM_EXTERN1:
		case IDM_EXTERN2:
		case IDM_EXTERN3:
			CheckMenuItem(GetMenu(hWnd), VideoSource + 1089, MF_UNCHECKED);
			VideoSource = wParam - 1089;
			Set_Capture(4);
			SetVideoSource(VideoSource);
			sprintf(Text, "Extern %d", VideoSource);
			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndKeyField, Text);
			Set_Capture(5);
			CheckMenuItem(GetMenu(hWnd), VideoSource + 1089, MF_CHECKED);
			break;

		case IDM_VIDEO:
			if (Capture_Video == FALSE)
			{
				Capture_Video = TRUE;
				Set_Capture(0);
				CheckMenuItem(GetMenu(hWnd), IDM_VIDEO, MF_CHECKED);
			}
			else
			{
				Set_Capture(1);
				Capture_Video = FALSE;
				CheckMenuItem(GetMenu(hWnd), IDM_VIDEO, MF_UNCHECKED);
			}
			break;

		case IDM_HWINFO:
			DialogBox(hInst, "HWINFO", hWnd, (DLGPROC) ChipSettingProc);
			break;

		case IDM_PLL:
			DialogBox(hInst, "PLLINFO", hWnd, (DLGPROC) PLLSettingProc);
			break;

		case IDM_IFORM:
			DialogBox(hInst, "IFORMINFO", hWnd, (DLGPROC) IFormSettingProc);
			break;

		case IDM_DONT_TOUCH:
			if (USETUNER == TRUE)
			{
				USETUNER = FALSE;
				CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH, MF_CHECKED);
			}
			else
			{
				USETUNER = TRUE;
				CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH, MF_UNCHECKED);
			}
			break;

		case IDM_DONT_TOUCH_CARD:
			if (USECARD == TRUE)
			{
				USECARD = FALSE;
				CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH_CARD, MF_CHECKED);
			}
			else
			{
				USECARD = TRUE;
				CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH_CARD, MF_UNCHECKED);
			}
			break;

		case IDM_MANUELL_TUNER:
			DialogBox(hInst, "TUNERSETTINGS", hWnd, (DLGPROC) TunerSettingProc);
			break;

		case IDM_VBI_VT:
			if (VBI_Flags & VBI_VT)
			{
				VBI_Flags -= VBI_VT;
				CheckMenuItem(GetMenu(hWnd), IDM_VBI_VT, MF_UNCHECKED);
				EnableMenuItem(GetMenu(hWnd), IDM_VT_OUT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXTSMALL, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VT_RESET, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_UNTERTITEL, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_PDC_OUT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VT_OUT, MF_GRAYED);

				break;
			}
			VBI_Flags += VBI_VT;
			CheckMenuItem(GetMenu(hWnd), IDM_VBI_VT, MF_CHECKED);
			EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXTSMALL, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXT, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_VT_RESET, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_UNTERTITEL, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_PDC_OUT, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_VT_OUT, MF_ENABLED);
			break;

		case IDM_VBI_VD:
			if (VBI_Flags & VBI_VD)
			{
				if (BeforeVD != 7)
				{
					Set_Capture(4);
					Sleep(30);
					VBI_Flags -= VBI_VD;
					VideoDat_Exit();
					CheckMenuItem(GetMenu(hWnd), IDM_VBI_VD, MF_UNCHECKED);
					VBI_lpf = 16;
					for(i = 0; i < 5; i++)
					{
						MakeVBITable(i, VBI_lpf);
					}
					CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_UNCHECKED);
					TVTYPE = BeforeVD;
					CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_CHECKED);
					EnableMenuItem(GetMenu(hWnd), IDM_VD_OUT, MF_GRAYED);
					Init_Screen_Struct();
					Set_Capture(5);
					break;
				}
				VBI_Flags -= VBI_VD;
				CheckMenuItem(GetMenu(hWnd), IDM_VBI_VD, MF_UNCHECKED);
				EnableMenuItem(GetMenu(hWnd), IDM_VD_OUT, MF_GRAYED);
				break;
			}

			BeforeVD = TVTYPE;
			if (TVTYPE != 7)
			{
				Set_Capture(4);
				Sleep(30);
				VideoDat_Init();
				VBI_Flags += VBI_VD;	// 
				CheckMenuItem(GetMenu(hWnd), IDM_VBI_VD, MF_CHECKED);
				VBI_lpf = 19;
				for(i = 0; i < 5; i++)
				{
					MakeVBITable(i, VBI_lpf);
				}
				CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_UNCHECKED);
				TVTYPE = 7;
				CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_CHECKED);
				EnableMenuItem(GetMenu(hWnd), IDM_VD_OUT, MF_ENABLED);
				Init_Screen_Struct();
				Set_Capture(5);
				break;
			}
			VideoDat_Init();
			VBI_Flags += VBI_VD;

			CheckMenuItem(GetMenu(hWnd), IDM_VBI_VD, MF_CHECKED);
			EnableMenuItem(GetMenu(hWnd), IDM_VD_OUT, MF_ENABLED);
			break;

		case IDM_VBI_VPS:
			if (VBI_Flags & VBI_VPS)
			{
				VBI_Flags -= VBI_VPS;
				CheckMenuItem(GetMenu(hWnd), IDM_VBI_VPS, MF_UNCHECKED);
				EnableMenuItem(GetMenu(hWnd), IDM_VPS_OUT, MF_GRAYED);
				break;
			}
			VBI_Flags += VBI_VPS;
			CheckMenuItem(GetMenu(hWnd), IDM_VBI_VPS, MF_CHECKED);
			EnableMenuItem(GetMenu(hWnd), IDM_VPS_OUT, MF_ENABLED);
			break;

		case IDM_VBI_IC:
			if (VBI_Flags & VBI_IC)
			{
				VBI_Flags -= VBI_IC;
				CheckMenuItem(GetMenu(hWnd), IDM_VBI_IC, MF_UNCHECKED);
				EnableMenuItem(GetMenu(hWnd), IDM_IC_OUT, MF_GRAYED);
				break;
			}
			VBI_Flags += VBI_IC;
			CheckMenuItem(GetMenu(hWnd), IDM_VBI_IC, MF_CHECKED);
			EnableMenuItem(GetMenu(hWnd), IDM_IC_OUT, MF_ENABLED);

			break;

		case IDM_UNTERTITEL:
			VThWnd = CreateDialog(hInst, "VIDEOTEXTUNTERTITEL", NULL, VideoTextUnterTitelProc);
			if (bAlwaysOnTop == TRUE)
				SetWindowPos(VThWnd, HWND_TOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);
			break;

		case IDM_VIDEODAT_SETUP:
			DialogBox(hInst, "VDSETUP", hWnd, VDSettingProc);
			break;

		case IDM_VT_SETUP:
			DialogBox(hInst, "VTSETUP", hWnd, VTSettingProc);
			break;

		case IDM_INTERCAST_SETUP:
			DialogBox(hInst, "ICSETUP", hWnd, ICSettingProc);
			break;

		case IDM_TOGGLE_SETTUNGS:
			DialogBox(hInst, "TOGGLESETTING", hWnd, ToggleSettingProc);
			break;

		case IDM_CALL_VIDEOTEXTSMALL:
			VTLarge = FALSE;
			VThWnd = CreateDialog(hInst, "VIDEOTEXTSMALL", NULL, VideoTextProc);
			if (bAlwaysOnTop == TRUE)
				SetWindowPos(VThWnd, HWND_TOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);
			break;

		case IDM_CALL_VIDEOTEXT:
			VTLarge = TRUE;
			VThWnd = CreateDialog(hInst, "VIDEOTEXT", NULL, VideoTextProc);
			if (bAlwaysOnTop == TRUE)
				SetWindowPos(VThWnd, HWND_TOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);
			break;
		case IDM_VT_RESET:
			VT_ChannelChange();
			break;

		case IDM_AUDIOSETTINGS:
			DialogBox(hInst, "AUDIOEINSTELLUNGEN", hWnd, AudioSettingProc);
			break;

		case IDM_AUDIOSETTINGS1:
			DialogBox(hInst, "AUDIOEINSTELLUNGEN1", hWnd, AudioSettingProc1);
			break;

		case IDM_VIDEOSETTINGS:
			DialogBox(hInst, "VIDEOEINSTELLUNGEN", hWnd, VideoSettingProc);
			break;

		case IDM_VPS_OUT:
			DialogBox(hInst, "VPSSTATUS", hWnd, VPSInfoProc);
			break;

		case IDM_IC_OUT:
			DialogBox(hInst, "ICSTATUS", hWnd, ICInfoProc);
			break;

		case IDM_VD_OUT:
			if (VD_RAW == TRUE)
				DialogBox(hInst, "VDSTATUSRAW", hWnd, VDInfoProcRaw);
			else
				DialogBox(hInst, "VDSTATUS", hWnd, VDInfoProc);
			break;

		case IDM_VT_OUT:
			DialogBox(hInst, "VTSTATUS", hWnd, VTInfoProc);
			break;

		case IDM_VBI:
			if (Capture_VBI == FALSE)
			{
				Start_VBI();
				Set_Capture(2);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_VT, MF_ENABLED);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_WINBIS, MF_ENABLED);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_IC, MF_ENABLED);
				if (VBI_Flags & VBI_IC)
				{
					EnableMenuItem(GetMenu(hWnd), IDM_IC_OUT, MF_ENABLED);
				}
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_VPS, MF_ENABLED);
				if (VBI_Flags & VBI_VPS)
				{
					EnableMenuItem(GetMenu(hWnd), IDM_VPS_OUT, MF_ENABLED);
				}

				EnableMenuItem(GetMenu(hWnd), IDM_VBI_VD, MF_ENABLED);

				if (VBI_Flags & VBI_VT)
				{
					EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXTSMALL, MF_ENABLED);
					EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXT, MF_ENABLED);
					EnableMenuItem(GetMenu(hWnd), IDM_VT_RESET, MF_ENABLED);
					EnableMenuItem(GetMenu(hWnd), IDM_UNTERTITEL, MF_ENABLED);
					EnableMenuItem(GetMenu(hWnd), IDM_PDC_OUT, MF_ENABLED);
					EnableMenuItem(GetMenu(hWnd), IDM_VT_OUT, MF_ENABLED);
				}

				Capture_VBI = TRUE;
				CheckMenuItem(GetMenu(hWnd), IDM_VBI, MF_CHECKED);
			}
			else
			{
				Capture_VBI = FALSE;
				Stop_Thread();
				Stop_VBI();
				Set_Capture(4);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_VT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_IC, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_WINBIS, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_VPS, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VBI_VD, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXTSMALL, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VT_RESET, MF_GRAYED);
				CheckMenuItem(GetMenu(hWnd), IDM_VBI, MF_UNCHECKED);
				EnableMenuItem(GetMenu(hWnd), IDM_UNTERTITEL, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_PDC_OUT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VT_OUT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_IC_OUT, MF_GRAYED);
				EnableMenuItem(GetMenu(hWnd), IDM_VPS_OUT, MF_GRAYED);

				Set_Capture(3);

			}
			break;

		case IDM_CAPTURE_PAUSE:
			if (Capture_Pause == FALSE)
			{
				Capture_Pause = TRUE;
				Set_Capture(4);
				CheckMenuItem(GetMenu(hWnd), IDM_CAPTURE_PAUSE, MF_CHECKED);
			}
			else
			{
				Set_Capture(5);
				Capture_Pause = FALSE;
				CheckMenuItem(GetMenu(hWnd), IDM_CAPTURE_PAUSE, MF_UNCHECKED);
			}
			break;

		case IDM_AUDIO_MIXER:
			DialogBox(hInst, "MIXERSETUP", hWnd, MixerSetupProc);
			break;

		case IDM_DX_LOCK:
			Stop_Thread();
			Set_Capture(4);
			if (USE_DX_LOCK == TRUE)
			{
				USE_DX_LOCK = FALSE;
				CheckMenuItem(GetMenu(hWnd), IDM_DX_LOCK, MF_UNCHECKED);
			}
			else
			{
				USE_DX_LOCK = TRUE;
				CheckMenuItem(GetMenu(hWnd), IDM_DX_LOCK, MF_CHECKED);
			}
			Init_Screen_Struct();
			Set_Capture(5);
			break;

		case IDM_STATUSBAR:
			if (bDisplayStatusBar == TRUE)
			{
				Stop_Thread();

				bDisplayStatusBar = FALSE;
				Stop_Thread();
				KillTimer(hWnd, 1);

				CheckMenuItem(GetMenu(hWnd), IDM_STATUSBAR, MF_UNCHECKED);
				Set_Capture(4);
				ShowWindow(hwndStatusBar, SW_HIDE);
				Init_Screen_Struct();
				Set_Capture(5);
				break;
			}
			bDisplayStatusBar = TRUE;
			Stop_Thread();
			SetTimer(hWnd, 1, 2000, NULL);
			CheckMenuItem(GetMenu(hWnd), IDM_STATUSBAR, MF_CHECKED);
			Set_Capture(4);
			ShowWindow(hwndStatusBar, SW_SHOW);
			Init_Screen_Struct();
			Set_Capture(5);

			break;
		case IDM_ON_TOP:
			Stop_Thread();
			Set_Capture(4);
			WStyle = GetWindowLong(hWnd, GWL_EXSTYLE);
			if (bAlwaysOnTop)
			{
				WStyle = WStyle ^ 8;
				i = SetWindowLong(hWnd, GWL_EXSTYLE, WStyle);
				bAlwaysOnTop = FALSE;
				SetWindowPos(hWnd, HWND_NOTOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);
				CheckMenuItem(GetMenu(hWnd), IDM_ON_TOP, MF_UNCHECKED);
			}
			else
			{
				WStyle = WStyle | 8;
				i = SetWindowLong(hWnd, GWL_EXSTYLE, WStyle);
				bAlwaysOnTop = TRUE;
				CheckMenuItem(GetMenu(hWnd), IDM_ON_TOP, MF_CHECKED);
				SetWindowPos(hWnd, HWND_TOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);

			}
			Init_Screen_Struct();
			Set_Capture(5);

			break;

		case IDM_ANALOGSCAN:
			DialogBox(hInst, "ANALOGSCAN", hWnd, (DLGPROC) AnalogScanProc);
			break;

		case IDM_KANAL_LISTE:
			DialogBox(hInst, "KANALLISTE", hWnd, (DLGPROC) ProgramListProc);
			break;

		case IDM_TREADPRIOR_0:
		case IDM_TREADPRIOR_1:
		case IDM_TREADPRIOR_2:
		case IDM_TREADPRIOR_3:
		case IDM_TREADPRIOR_4:
			CheckMenuItem(GetMenu(hWnd), ThreadClassId + 1150, MF_UNCHECKED);
			ThreadClassId = wParam - 1150;
			CheckMenuItem(GetMenu(hWnd), ThreadClassId + 1150, MF_CHECKED);
			Set_Capture(4);
			Sleep(100);
			Set_Capture(5);
			break;

		case IDM_PRIORCLASS_0:
		case IDM_PRIORCLASS_1:
		case IDM_PRIORCLASS_2:
			CheckMenuItem(GetMenu(hWnd), PriorClassId + 1160, MF_UNCHECKED);
			PriorClassId = wParam - 1160;
			CheckMenuItem(GetMenu(hWnd), PriorClassId + 1160, MF_CHECKED);
			strcpy(Text, "Can't set Priority");
			if (PriorClassId == 0)
			{
				if (SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS) == TRUE)
					strcpy(Text, "Normal Priority");
			}
			else if (PriorClassId == 1)
			{
				if (SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS) == TRUE)
					strcpy(Text, "High Priority");
			}
			else
			{
				if (SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS) == TRUE)
					strcpy(Text, "Real-Time Priority");
			}
			SetWindowText(hwndTextField, Text);
			break;

		case IDM_TUNER_4:
			CheckMenuItem(GetMenu(hWnd), TunerType + 1100, MF_UNCHECKED);
			CheckMenuItem(GetMenu(hWnd), IDM_EXTERN1, MF_UNCHECKED);
			CheckMenuItem(GetMenu(hWnd), IDM_EXTERN2, MF_UNCHECKED);
			CheckMenuItem(GetMenu(hWnd), IDM_EXTERN3, MF_UNCHECKED);
			TunerType = wParam - 1100;
			CheckMenuItem(GetMenu(hWnd), TunerType + 1100, MF_CHECKED);
			Set_Capture(4);
			VideoSource = 0;
			SetVideoSource(VideoSource);
			Set_Capture(5);
			break;

		case IDM_TUNER_0:
		case IDM_TUNER_1:
		case IDM_TUNER_2:
		case IDM_TUNER_3:
		case IDM_TUNER_5:
		case IDM_TUNER_6:
		case IDM_TUNER_7:
		case IDM_TUNER_8:

			CheckMenuItem(GetMenu(hWnd), TunerType + 1100, MF_UNCHECKED);
			CheckMenuItem(GetMenu(hWnd), IDM_EXTERN1, MF_UNCHECKED);
			CheckMenuItem(GetMenu(hWnd), IDM_EXTERN2, MF_UNCHECKED);
			CheckMenuItem(GetMenu(hWnd), IDM_EXTERN3, MF_UNCHECKED);

			VideoSource = 0;
			TunerType = wParam - 1100;
			Set_Capture(4);
			Init_Tuner(TunerType);
			SetVideoSource(VideoSource);
			i = 0;
			sprintf(Text, "%04d. %s ", CurrentProgramm + 1, Programm[CurrentProgramm].Name);
			if (bDisplayStatusBar == TRUE)
				SetWindowText(hwndKeyField, Text);

			Set_Capture(5);

			CheckMenuItem(GetMenu(hWnd), TunerType + 1100, MF_CHECKED);
			break;

		case IDM_TYPEFORMAT_0:
		case IDM_TYPEFORMAT_1:
		case IDM_TYPEFORMAT_2:
		case IDM_TYPEFORMAT_3:
		case IDM_TYPEFORMAT_4:
		case IDM_TYPEFORMAT_5:
		case IDM_TYPEFORMAT_6:
		case IDM_TYPEFORMAT_7:
		case IDM_TYPEFORMAT_8:
		case IDM_TYPEFORMAT_9:
			CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_UNCHECKED);
			TVTYPE = wParam - 1120;
			CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_CHECKED);
			Set_Capture(4);
			Init_Screen_Struct();
			Set_Capture(5);
			break;

		case IDM_COLORFORMAT_0:
		case IDM_COLORFORMAT_1:
		case IDM_COLORFORMAT_2:
		case IDM_COLORFORMAT_3:
		case IDM_COLORFORMAT_4:
		case IDM_COLORFORMAT_5:
		case IDM_COLORFORMAT_6:
		case IDM_COLORFORMAT_7:
		case IDM_COLORFORMAT_8:
		case IDM_COLORFORMAT_9:
		case IDM_COLORFORMAT_10:
			CheckMenuItem(GetMenu(hWnd), ColourFormat + 1130, MF_UNCHECKED);
			ColourFormat = wParam - 1130;
			Set_Capture(4);
			SetColourFormat(ColourFormat);
			Set_Capture(5);
			CheckMenuItem(GetMenu(hWnd), ColourFormat + 1130, MF_CHECKED);
			break;
		case IDM_SPACEBAR:
			gPulldownMode++;
			if(gPulldownMode == LAST_ONE)
			{
				gPulldownMode = VIDEO_MODE;
			}
			UpdatePulldownStatus();
			break;
		}
		break;

	case WM_CREATE:
		MainWndOnCreate(hWnd);
		return TRUE;

	case INIT_BT:
		MainWndOnInitBT(hWnd);
		return TRUE;

	case WM_RBUTTONUP:
		CShowCursor = !CShowCursor;
		i = ShowCursor(CShowCursor);
		break;

	case WM_TIMER:
		if (wParam >= 200)
		{
			KillTimer(hWnd, wParam);
		}

		if (wParam == 22)
		{
			return (TRUE);
		}

		if (CurrentCapture != 4)
		{
			if (wParam == 8)
			{
				if (bDisplayStatusBar == TRUE)
					MSP_Print_Mode();
				if (AutoStereoSelect == TRUE)
					MSPWatch_Mode();
				return (TRUE);
			}
		}

		if (wParam == 1)
		{
			if (!VideoPresent())
			{
				SetWindowText(hwndTextField, " No Video Signal Found");
				return (TRUE);
			}

			Text[0] = 0x00;
			if (Packet30.Identifier[0] != 0x00)
			{
				sprintf(Text, "%s ", Packet30.Identifier);
				Packet30.Identifier[0] = 0x00;
			}
			else if (VPS_lastname[0] != 0x00)
			{
				sprintf(Text, "%s ", VPS_lastname);
				VPS_lastname[0] = 0x00;
			}

			strcpy(Text1, Text);

			if (System_In_Mute == TRUE)
				sprintf(Text1, "Volume Mute");
			SetWindowText(hwndTextField, Text1);
			return (TRUE);
		}

		if (wParam == 99)
		{
			KillTimer(hWnd, 99);
			i = atoi(ChannelString);
			ChannelString[0] = 0x00;
			i = i - 1;
			SetAudioSource(4);

			if ((i >= 0) && (i < MAXPROGS))
			{

				if ((Programm[i].freq != 0) && (ValidModes(Programm[i].Typ) == TRUE))
				{
					CurrentProgramm = i;
					if (Programm[CurrentProgramm].Typ == 'A')
					{
						Tuner_SetFrequency(TunerType, MulDiv(Programm[CurrentProgramm].freq * 1000, 16, 1000000));
					}
					if (bDisplayStatusBar == TRUE)
					{
						sprintf(Text, "%04d. %s ", CurrentProgramm + 1, Programm[CurrentProgramm].Name);
						SetWindowText(hwndKeyField, Text);
					}
				}

				VT_ChannelChange();
				Sleep(20);
				SetAudioSource(AudioSource);
			}

		}
		return (TRUE);

	case WM_SYSCOMMAND:		//            Verhindern vom ScreenSaver 
		switch (wParam & 0xFFF0)
		{
		case SC_SCREENSAVE:
		case SC_MONITORPOWER:
			return 0;
			break;
		}

	case WM_SIZE:
	case WM_MOVE:
		GetWindowRect(hWnd, &rScreen);
		// oly recreate overlay if the window has actually moved
		if ((emstarty != rScreen.top) || 
			(emsizey != (rScreen.bottom - rScreen.top)) || 
			(emstartx != rScreen.left) || 
			(emsizex != (rScreen.right - rScreen.left)))
		{
			AdjustStatusBar(hWnd);
			if (bDoResize == TRUE)
			{
				Stop_Thread();
				if (CurrentCapture != 0)
				{
					Set_Capture(4);
					Init_Screen_Struct();
					Set_Capture(5);
				}
				else
				{
					Init_Screen_Struct();
				}
			
				emstarty = rScreen.top;
				emsizey = rScreen.bottom - rScreen.top; 
				emstartx = rScreen.left;
				emsizex = rScreen.right - rScreen.left;
			}
		}
		break;

	case WM_CHAR:
		if (((char) wParam >= '0') && ((char) wParam <= '9'))
		{
			sprintf(Text, "%c", wParam);
			strcat(ChannelString, Text);
			if (strlen(ChannelString) >= 4)
				SetTimer(hWnd, 99, 100, NULL);
			SetTimer(hWnd, 99, 1000, NULL);
		}

		break;

	case WM_QUERYENDSESSION:
	case WM_DESTROY:
		Stop_Thread();
		WriteSettingsToIni();

		if(bHardwareFound)
		{
			Stop_VBI();
			SetAudioSource(4);
			Set_Capture(4);
		}

		Sleep(100);
		Exit_Mixer();
		InterCast_Exit();
		VideoDat_Exit();
		for (i = 0; i < 800; i++)
		{
			if (VTFrame[i].SubPage != NULL)
				free(VTFrame[i].SubPage);
			VTFrame[i].SubPage = NULL;
			VTFrame[i].SubCount = 0;
		}
		Free_DMA(&Risc_dma);
		Free_DMA(&Vbi_dma[0]);
		Free_DMA(&Vbi_dma[1]);
		Free_DMA(&Vbi_dma[2]);
		Free_DMA(&Vbi_dma[3]);
		Free_DMA(&Vbi_dma[4]);

		Free_Display_DMA(0);
		Free_Display_DMA(1);
		Free_Display_DMA(2);
		Free_Display_DMA(3);
		Free_Display_DMA(4);

		Free_DMA(&Burst_dma[0]);
		Free_DMA(&Burst_dma[1]);
		Free_DMA(&Burst_dma[2]);
		Free_DMA(&Burst_dma[3]);
		Free_DMA(&Burst_dma[4]);

		for (i = 0; i < MAXVTDIALOG; i++)
		{
			free(VTScreen[i]);
		}

		ExitTV();

		PostQuitMessage(0);
		return (TRUE);
	}

	return (DefWindowProc(hWnd, message, wParam, lParam));
}

void MainWndOnInitBT(HWND hWnd)
{
	char Text[128];
	int i;

	MSPStatus[0] = 0x00;
	CurrentProgramm = InitialProg;

	if (Init_TV_Karte(hWnd) == TRUE)
	{
		if (Init_BT_Kernel_Memory())
		{
			bHardwareFound = TRUE;
		}
	}

	if (bHardwareFound)
	{
		if (Init_Memory() == FALSE)
		{

			for (i = 0; i < 800; i++)
			{
				if (VTFrame[i].SubPage != NULL)
					free(VTFrame[i].SubPage);
				VTFrame[i].SubPage = NULL;
				VTFrame[i].SubCount = 0;
			}

			InterCast_Exit();
			Exit_Mixer();

			Free_DMA(&Risc_dma);
			Free_DMA(&Vbi_dma[0]);
			Free_DMA(&Vbi_dma[1]);
			Free_DMA(&Vbi_dma[2]);
			Free_DMA(&Vbi_dma[3]);
			Free_DMA(&Vbi_dma[4]);

			Free_Display_DMA(0);
			Free_Display_DMA(1);
			Free_Display_DMA(2);
			Free_Display_DMA(3);
			Free_Display_DMA(4);

			Free_DMA(&Burst_dma[0]);
			Free_DMA(&Burst_dma[1]);
			Free_DMA(&Burst_dma[2]);
			Free_DMA(&Burst_dma[3]);
			Free_DMA(&Burst_dma[4]);
			BT8X8_Close();
			bHardwareFound = FALSE;
		}
	}

	WStyle = GetWindowLong(hWnd, GWL_EXSTYLE);
	if (bAlwaysOnTop == FALSE)
	{
		WStyle = WStyle ^ 8;
		i = SetWindowLong(hWnd, GWL_EXSTYLE, WStyle);
		SetWindowPos(hWnd, HWND_NOTOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);
		CheckMenuItem(GetMenu(hWnd), IDM_ON_TOP, MF_UNCHECKED);
	}
	else
	{
		WStyle = WStyle | 8;
		i = SetWindowLong(hWnd, GWL_EXSTYLE, WStyle);
		CheckMenuItem(GetMenu(hWnd), IDM_ON_TOP, MF_CHECKED);
		SetWindowPos(hWnd, HWND_TOPMOST, 10, 10, 20, 20, SWP_NOMOVE | SWP_NOCOPYBITS | SWP_NOSIZE);
	}

	if (bHardwareFound)
	{
		Init_BT_HardWare(hWnd);
		sprintf(TunerStatus, "No Device on I2C-Bus");
		if (USETUNER == TRUE)
		{
			sprintf(Text, "No Tuner");
			if (Init_Tuner(TunerType) == TRUE)
			{
				sprintf(Text, "Tuner OK");

			}
			SetDlgItemText(SplashWnd, IDC_TEXT4, Text);

		}
		else
		{
			sprintf(TunerStatus, "Tuner disabled");
			sprintf(Text, "Tuner disabled.");
			SetDlgItemText(SplashWnd, IDC_TEXT4, Text);
		}

		if (MSPStatus[0] == 0x00)
		{
			sprintf(MSPStatus, "No Device on I2C-Bus");
			sprintf(Text, "No MSP-Device");
			if (Init_Audio(0x80, 0x81) == TRUE)
			{
				sprintf(Text, "MSP-Device OK");
				sprintf(MSPStatus, "MSP-Device I2C-Bus I/O 0x80/0x81");
			}
		}
		else
		{
			sprintf(Text, "MSP-Device OK");
		}
		SetDlgItemText(SplashWnd, IDC_TEXT5, Text);

		if (Has_MSP == TRUE)
		{
			SetTimer(hWnd, 8, 10000, NULL);
			if (AutoStereoSelect == TRUE)
			{
				CheckMenuItem(GetMenu(hWnd), IDM_AUTOSTEREO, MF_CHECKED);
			}
		}

		if (VideoSource == 1)
			sprintf(Text, "External 1");
		else if (VideoSource == 2)
			sprintf(Text, "External 2");
		else if (VideoSource == 3)
			sprintf(Text, "External 3");
		else
		{
			if ((CurrentProgramm >= 0) && (CurrentProgramm < MAXPROGS))
				sprintf(Text, "%04d. %s ", CurrentProgramm + 1, Programm[CurrentProgramm].Name);
		}

		if (bDisplayStatusBar == TRUE)
			SetWindowText(hwndKeyField, Text);
	}

	if (!bHardwareFound)
	{
		SetDlgItemText(SplashWnd, IDC_TEXT1, "");
		SetDlgItemText(SplashWnd, IDC_TEXT2, "No");
		SetDlgItemText(SplashWnd, IDC_TEXT3, "Suitable");
		SetDlgItemText(SplashWnd, IDC_TEXT4, "Hardware");
		SetDlgItemText(SplashWnd, IDC_TEXT5, "");
		ExitTV();
		Sleep(5000);
		PostMessage(hWnd, WM_DESTROY, 0, 0);
		return;
	}

	if (Show_Menu == FALSE)
	{
		Show_Menu = TRUE;
		SendMessage(hWnd, WM_COMMAND, IDM_TOGGLE_MENU, 0);
	}

	if (CurrentProgramm >= 0)
	{
		if ((Programm[CurrentProgramm].Typ == 'A') && (bHardwareFound))
			Tuner_SetFrequency(TunerType, MulDiv(Programm[CurrentProgramm].freq * 1000, 16, 1000000));
	}

	if (bHardwareFound)
	{
		Stop_Thread();
		DestroyMenu(hMenu);
		hMenu = LoadMenu(hInst, "ANALOGMENU");
		if (Show_Menu == TRUE)
			SetMenu(hWnd, hMenu);
		DestroyAcceleratorTable(hAccel);
		hAccel = LoadAccelerators(hInst, "ANALOGACCEL");
		SetMenuAnalog();
		bDoResize = TRUE;
		for (i = 0; i < 5; i++)
		{
			pDisplay[i] = Display_dma[i]->dwUser;
		}

		Init_Screen_Struct();
		Set_Capture(5);
		Sleep(100);
		SetAudioSource(AudioSource);

	}

	SetTimer(hWnd, 22, 1000, NULL);
	SetTimer(hWnd, 1, 2500, NULL);
}

void MainWndOnCreate(HWND hWnd)
{
	char Text[128];
	int i;

	GetSystemInfo(&SysInfo);
	SetDlgItemText(SplashWnd, IDC_TEXT1, "Table Build");
	SetDlgItemText(SplashWnd, IDC_TEXT2, "");
	SetDlgItemText(SplashWnd, IDC_TEXT3, "");
	SetDlgItemText(SplashWnd, IDC_TEXT4, "");
	SetDlgItemText(SplashWnd, IDC_TEXT5, "");
	SetMenu(hWnd, hMenu);
	Sleep(100);
	
	SetDlgItemText(SplashWnd, IDC_TEXT2, "InterCast");
	for (i = 0; i < 12; i++)
	{
		UTPages[i] = 0;
	}
	InterCast_Init();

	Sleep(100);
	SetDlgItemText(SplashWnd, IDC_TEXT3, "VideoText");
	for (i = 0; i < 800; i++)
	{
		VTFrame[i].SubPage = NULL;
		VTFrame[i].SubCount = 0;
	}

	VT_ChannelChange();

	for (i = 0; i < MAXVTDIALOG; i++)
	{
		VTDialog[i].Dialog = NULL;
	}

	Load_Program_List();
	Load_Country_Settings();

	VTScreen[0] = NULL;

	// DIB-Bitmap VideoText erzeugen
	SetDlgItemText(SplashWnd, IDC_TEXT4, "HQ-Color");

	CheckMenuItem(GetMenu(hWnd), ThreadClassId + 1150, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), PriorClassId + 1160, MF_CHECKED);

	if (USE_MIXER == TRUE)
	{
		Sleep(100);
		SetDlgItemText(SplashWnd, IDC_TEXT1, "Sound-System");
		SetDlgItemText(SplashWnd, IDC_TEXT2, "");
		SetDlgItemText(SplashWnd, IDC_TEXT3, "");
		SetDlgItemText(SplashWnd, IDC_TEXT4, "");
		SetDlgItemText(SplashWnd, IDC_TEXT5, "");

		Enumerate_Sound_SubSystem();
		if (SoundSystem.DeviceAnzahl == 0)
		{
			SetDlgItemText(SplashWnd, TEXT3, "No Soundsystem found");
		}
		else
		{
			if (SoundSystem.DeviceAnzahl >= 1)
				SetDlgItemText(SplashWnd, TEXT3, SoundSystem.MixerDev[0].szPname);
			if (SoundSystem.DeviceAnzahl >= 2)
				SetDlgItemText(SplashWnd, TEXT4, SoundSystem.MixerDev[1].szPname);
			if (SoundSystem.DeviceAnzahl >= 3)
				SetDlgItemText(SplashWnd, TEXT5, SoundSystem.MixerDev[2].szPname);
			Sleep(100);
			SetDlgItemText(SplashWnd, IDC_TEXT3, "");
			SetDlgItemText(SplashWnd, IDC_TEXT4, "");
			SetDlgItemText(SplashWnd, IDC_TEXT5, "");

			if (Volume.SoundSystem >= 0)
				sprintf(Text, "%s", SoundSystem.MixerDev[Volume.SoundSystem].szPname);
			else if (Mute.SoundSystem >= 0)
				sprintf(Text, "%s", SoundSystem.MixerDev[Mute.SoundSystem].szPname);
			else
				sprintf(Text, "%s", SoundSystem.MixerDev[0].szPname);
			SetDlgItemText(SplashWnd, IDC_TEXT2, Text);

			if (Volume.SoundSystem >= 0)
				sprintf(Text, "Volume -> %s", SoundSystem.To_Lines[Volume.SoundSystem].To_Connection[Volume.Destination].MixerConnections[Volume.Connection].szName);
			else
				sprintf(Text, "Volume Not Set");
			SetDlgItemText(SplashWnd, IDC_TEXT3, Text);

			if (Mute.SoundSystem >= 0)
				sprintf(Text, "%s -> %s  %s", SoundSystem.To_Lines[Mute.SoundSystem].To_Connection[Mute.Destination].MixerConnections[Mute.Connection].szName,
						SoundSystem.To_Lines[Mute.SoundSystem].MixerLine[Mute.Destination].szName,
						SoundSystem.To_Lines[Mute.SoundSystem].To_Connection[Mute.Destination].To_Control[Mute.Connection].MixerControl[Mute.Control].szName);
			else
				sprintf(Text, "Mute Not Set");
			SetDlgItemText(SplashWnd, IDC_TEXT4, Text);

			if (MIXER_LINKER_KANAL == -1)
				Mixer_Get_Volume(&MIXER_LINKER_KANAL, &MIXER_RECHTER_KANAL);
			Mixer_Set_Defaults();
			Get_Volume_Param();
			Mixer_Set_Volume(MIXER_LINKER_KANAL, MIXER_RECHTER_KANAL);
		}
	}
	SetDlgItemText(SplashWnd, IDC_TEXT1, "System Analysis");
	SetDlgItemText(SplashWnd, IDC_TEXT2, "");
	SetDlgItemText(SplashWnd, IDC_TEXT3, "");
	SetDlgItemText(SplashWnd, IDC_TEXT4, "");
	SetDlgItemText(SplashWnd, IDC_TEXT5, "");

	Sleep(100);
	sprintf(Text, "Prozessor %d ", SysInfo.dwProcessorType);
	SetDlgItemText(SplashWnd, IDC_TEXT2, Text);
	sprintf(Text, "Number %d ", SysInfo.dwNumberOfProcessors);
	SetDlgItemText(SplashWnd, IDC_TEXT3, Text);

	if (SysInfo.dwNumberOfProcessors > 1)
	{
		if (AusgabeProzessor == 0)
		{
			if (SysInfo.dwNumberOfProcessors == 2)
			{
				MainProzessor = 0;
				VBIProzessor = 0;
				AusgabeProzessor = 1;
			}
			if (SysInfo.dwNumberOfProcessors == 3)
			{
				MainProzessor = 0;
				VBIProzessor = 1;
				AusgabeProzessor = 2;
			}
			if (SysInfo.dwNumberOfProcessors > 3)
			{
				MainProzessor = 0;
				VBIProzessor = 2;
				AusgabeProzessor = 3;
			}

		}

		SetDlgItemText(SplashWnd, IDC_TEXT1, "Multi-Processor");
		sprintf(Text, "Main-CPU %d ", MainProzessor);
		SetDlgItemText(SplashWnd, IDC_TEXT2, Text);
		sprintf(Text, "VBI-CPU %d ", VBIProzessor);
		SetDlgItemText(SplashWnd, IDC_TEXT4, Text);
		sprintf(Text, "DECODE-CPU %d ", AusgabeProzessor);
		SetDlgItemText(SplashWnd, IDC_TEXT5, Text);
		Sleep(100);
	}

	ProzessorMask = 1 << (MainProzessor);
	i = SetThreadAffinityMask(GetCurrentThread(), ProzessorMask);

	SetDlgItemText(SplashWnd, IDC_TEXT1, "Hardware Analyse");
	SetDlgItemText(SplashWnd, IDC_TEXT2, "");
	SetDlgItemText(SplashWnd, IDC_TEXT3, "");
	SetDlgItemText(SplashWnd, IDC_TEXT4, "");
	SetDlgItemText(SplashWnd, IDC_TEXT5, "");
	Sleep(200);

	InitTV(hWnd, FALSE, 768, 576);

	if (USE_DX_LOCK == TRUE)
		CheckMenuItem(GetMenu(hWnd), IDM_DX_LOCK, MF_CHECKED);
	if (VBI_Flags & VBI_VT)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_VBI_VT, MF_CHECKED);
		if (Capture_VBI == TRUE)
		{
			EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXTSMALL, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXT, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_VT_RESET, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_UNTERTITEL, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_PDC_OUT, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_VT_OUT, MF_ENABLED);
		}
	}
	if (VBI_Flags & VBI_IC)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_VBI_IC, MF_CHECKED);
		if (Capture_VBI == TRUE)
		{
			EnableMenuItem(GetMenu(hWnd), IDM_IC_OUT, MF_ENABLED);
		}
	}

	if (VBI_Flags & VBI_VPS)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_VBI_VPS, MF_CHECKED);
		if (Capture_VBI == TRUE)
		{
			EnableMenuItem(GetMenu(hWnd), IDM_VPS_OUT, MF_ENABLED);
		}
	}

	if (USECARD == FALSE)
		CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH_CARD, MF_CHECKED);

	if (USETUNER == FALSE)
	{
		TunerType = 4;
		VideoSource = 0;
		CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH, MF_CHECKED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_0, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_1, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_2, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_3, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_5, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_6, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_7, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_8, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_CHANNELPLUS, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_CHANNELMINUS, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_ANALOGSCAN, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_MANUELL_TUNER, MF_GRAYED);
	}

	CheckMenuItem(GetMenu(hWnd), CardType + 1080, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), AudioSource + 1110, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), ColourFormat + 1130, MF_CHECKED);
	if (VideoSource > 0)
		CheckMenuItem(GetMenu(hWnd), VideoSource + 1089, MF_CHECKED);
	else
	{
		CheckMenuItem(GetMenu(hWnd), TunerType + 1100, MF_CHECKED);
	}

	SetTimer(hWnd, 10, 5000, NULL);

	PostMessage(hWnd, INIT_BT, 0, 0);
}

// delete if below one works
void Init_Screen_StructOld()
{
	RECT rRect;
	RECT rSrcRect;
	RECT rScreen;

	int MaxX, MaxY;

	GetClientRect(hWnd, &rScreen);
	ClientToScreen(hWnd, (POINT *) & rScreen.left);
	ClientToScreen(hWnd, (POINT *) & rScreen.right);

	if (rScreen.left < 0)
		rScreen.left = 0;
	if (rScreen.top < 0)
		rScreen.top = 0;
	if (rScreen.right > GetSystemMetrics(SM_CXSCREEN))
		rScreen.right = GetSystemMetrics(SM_CXSCREEN);
	if (rScreen.bottom > GetSystemMetrics(SM_CYSCREEN))
		rScreen.bottom = GetSystemMetrics(SM_CYSCREEN);

	Destroy_Overlay();

	CurrentX = (rScreen.right - rScreen.left);
	CurrentY = (rScreen.bottom - rScreen.top);
	// Make sure CurrentX is even
	CurrentX = (CurrentX / 2) * 2;

	if (bDisplayStatusBar == TRUE)
		CurrentY -= 21;

	if (CurrentY <= 10)
		CurrentY = 10;
	if (CurrentX <= 10)
		CurrentX = 10;

	MaxY = CurrentY;
	if (MaxY > 1024)
		MaxY = 1024;
	MaxX = CurrentX;

	if (CurrentX > TVSettings[TVTYPE].wCropWidth)
		CurrentX = TVSettings[TVTYPE].wCropWidth;
	if (CurrentY > TVSettings[TVTYPE].wCropHeight)
		CurrentY = TVSettings[TVTYPE].wCropHeight;

	if (CurrentX > 768)
		CurrentX = 768;


	if (MaxX < CurrentX)
		CreateOverlay(MaxX, MaxY);
	else
		CreateOverlay(CurrentX, MaxY);

	GetClientRect(hWnd, &rRect);
	ClientToScreen(hWnd, (POINT *) & rRect.left);
	ClientToScreen(hWnd, (POINT *) & rRect.right);
	if (bDisplayStatusBar == TRUE)
		rRect.bottom -= 21;

	if (rRect.left < 0)
		rRect.left = 0;
	if (rRect.top < 0)
		rRect.top = 0;
	if (rRect.right > GetSystemMetrics(SM_CXSCREEN))
		rRect.right = GetSystemMetrics(SM_CXSCREEN);
	if (rRect.bottom > GetSystemMetrics(SM_CYSCREEN))
		rRect.bottom = GetSystemMetrics(SM_CYSCREEN);

	rSrcRect.left = 0;
	rSrcRect.top = 0;
	rSrcRect.right = CurrentX;
	rSrcRect.bottom = CurrentY;

	OverlayUpdate(&rSrcRect, &rRect, DDOVER_SHOW, TRUE);

	Black_Surface();

	if (bHardwareFound)
		SetGeoSize(CurrentX, CurrentY);
	return;
}

void Init_Screen_Struct()
{
	RECT rOverlayDest;
	RECT rOverlaySrc;

	int DestWidth, DestHeight;

	Destroy_Overlay();

	CurrentX = TVSettings[TVTYPE].wCropWidth;
	CurrentY = TVSettings[TVTYPE].wCropHeight;

	CreateOverlay(CurrentX, CurrentY);

	// to start off with we will display the whole
	// input area
	rOverlaySrc.left = 0;
	rOverlaySrc.top = 0;
	rOverlaySrc.right = CurrentX;
	rOverlaySrc.bottom = CurrentY;

	// get main window client area
	// and convert to screen coordinates
	GetClientRect(hWnd, &rOverlayDest);
	ClientToScreen(hWnd, (POINT *) &(rOverlayDest.left));
	ClientToScreen(hWnd, (POINT *) &(rOverlayDest.right));
	if (bDisplayStatusBar == TRUE)
	{
		rOverlayDest.bottom -= 21;
	}

	// crop the Destination rect so that the
	// overlay destination region is 
	// always on the screen
	// we will also update the source area to reflect this
	// so that we see the appropriate portion
	// on the screen
	// (this should make us compatable with YXY)
	DestHeight = rOverlayDest.bottom - rOverlayDest.top;
	DestWidth = rOverlayDest.right - rOverlayDest.left;
	
	if (rOverlayDest.left < 0 && DestWidth > 0)
	{
		rOverlaySrc.left = (CurrentX * -rOverlayDest.left) / DestWidth;
		rOverlayDest.left = 0;
	}
	if (rOverlayDest.top < 0 && DestHeight > 0)
	{
		rOverlaySrc.top = (CurrentY * -rOverlayDest.top) / DestHeight;
		rOverlayDest.top = 0;
	}
	if (rOverlayDest.right >= GetSystemMetrics(SM_CXSCREEN) && DestWidth > 0)
	{
		rOverlaySrc.right -= (rOverlayDest.right - GetSystemMetrics(SM_CXSCREEN)) * 
							CurrentX / DestWidth;
		rOverlayDest.right = GetSystemMetrics(SM_CXSCREEN) - 1;
	}
	if (rOverlayDest.bottom >= GetSystemMetrics(SM_CYSCREEN) && DestHeight > 0)
	{
		rOverlaySrc.bottom -= (rOverlayDest.bottom - GetSystemMetrics(SM_CYSCREEN)) * 
							CurrentY / DestHeight;
		rOverlayDest.bottom = GetSystemMetrics(SM_CYSCREEN) - 1;
	}

	OverlayUpdate(&rOverlaySrc, &rOverlayDest, DDOVER_SHOW, TRUE);

	Black_Surface();

	if (bHardwareFound)
	{
		SetGeoSize(CurrentX, CurrentY);
	}
	return;
}

void SetMenuAnalog()
{
	CheckMenuItem(GetMenu(hWnd), ThreadClassId + 1150, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), PriorClassId + 1160, MF_CHECKED);

	if (USE_DX_LOCK == TRUE)
		CheckMenuItem(GetMenu(hWnd), IDM_DX_LOCK, MF_CHECKED);
	if (VBI_Flags & VBI_VT)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_VBI_VT, MF_CHECKED);
		if (Capture_VBI == TRUE)
		{
			EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXTSMALL, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_CALL_VIDEOTEXT, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_VT_RESET, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_UNTERTITEL, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_PDC_OUT, MF_ENABLED);
			EnableMenuItem(GetMenu(hWnd), IDM_VT_OUT, MF_ENABLED);
		}
	}
	if (VBI_Flags & VBI_IC)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_VBI_IC, MF_CHECKED);
		if (Capture_VBI == TRUE)
		{
			EnableMenuItem(GetMenu(hWnd), IDM_IC_OUT, MF_ENABLED);
		}
	}

	if (VBI_Flags & VBI_VPS)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_VBI_VPS, MF_CHECKED);
		if (Capture_VBI == TRUE)
		{
			EnableMenuItem(GetMenu(hWnd), IDM_VPS_OUT, MF_ENABLED);
		}
	}

	if (USECARD == FALSE)
		CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH_CARD, MF_CHECKED);

	if (USETUNER == FALSE)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_DONT_TOUCH, MF_CHECKED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_0, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_1, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_2, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_3, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_5, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_6, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_7, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_TUNER_8, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_CHANNELPLUS, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_CHANNELMINUS, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_ANALOGSCAN, MF_GRAYED);
		EnableMenuItem(GetMenu(hWnd), IDM_MANUELL_TUNER, MF_GRAYED);
	}

	CheckMenuItem(GetMenu(hWnd), CountryCode + 5000, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), CardType + 1080, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), AudioSource + 1110, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), TVTYPE + 1120, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), ColourFormat + 1130, MF_CHECKED);
	if (VideoSource > 0)
		CheckMenuItem(GetMenu(hWnd), VideoSource + 1089, MF_CHECKED);
	else
	{
		CheckMenuItem(GetMenu(hWnd), TunerType + 1100, MF_CHECKED);
	}

	CheckMenuItem(GetMenu(hWnd), 1600 + MSPMode, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), 1630 + MSPStereo, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), 1610 + MSPMajorMode, MF_CHECKED);
	CheckMenuItem(GetMenu(hWnd), 1620 + MSPMinorMode, MF_CHECKED);
	if (Capture_Video == TRUE)
		CheckMenuItem(GetMenu(hWnd), IDM_VIDEO, MF_CHECKED);
	if (Capture_VBI == TRUE)
	{
		CheckMenuItem(GetMenu(hWnd), IDM_VBI, MF_CHECKED);
		EnableMenuItem(GetMenu(hWnd), IDM_VBI_VT, MF_ENABLED);
		EnableMenuItem(GetMenu(hWnd), IDM_VBI_IC, MF_ENABLED);
		EnableMenuItem(GetMenu(hWnd), IDM_VBI_VD, MF_ENABLED);
		EnableMenuItem(GetMenu(hWnd), IDM_VBI_VPS, MF_ENABLED);
	}
}

void Set_Mode_Analog(void)
{
	int i;

	bDoResize = FALSE;
	Set_Capture(4);
	Stop_Thread();
	KillTimer(hWnd, 22);
	DestroyMenu(hMenu);
	hMenu = LoadMenu(hInst, "ANALOGMENU");
	if (Show_Menu == TRUE)
		SetMenu(hWnd, hMenu);
	SetMenuAnalog();
	DestroyAcceleratorTable(hAccel);
	hAccel = LoadAccelerators(hInst, "ANALOGACCEL");
	for (i = 0; i < 5; i++)
	{
		pDisplay[i] = Display_dma[i]->dwUser;
	}
	Init_Screen_Struct();
	bDoResize = TRUE;
	Set_Capture(5);
	Sleep(100);
	SetAudioSource(AudioSource);
}

